import React, { useState } from 'react';
import {
  Youtube,
  MessageCircle,
  Bell,
  Camera,
  Sliders,
  Play,
  Share2,
  ExternalLink,
  ShieldCheck,
  Check,
  Volume2,
  Flame,
  Search,
} from 'lucide-react';

interface PhoneControlScreenProps {
  onOpenScreenTools: () => void;
  onSendAlyaMessage: (msg: string) => void;
  userName: string;
}

export const PhoneControlScreen: React.FC<PhoneControlScreenProps> = ({
  onOpenScreenTools,
  onSendAlyaMessage,
  userName,
}) => {
  const [youtubeQuery, setYoutubeQuery] = useState('chill anime lofi beats');
  const [activeTab, setActiveTab] = useState<'apps' | 'system' | 'notifications' | 'automation'>('apps');
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  const apps = [
    {
      name: 'YouTube',
      category: 'Media',
      icon: <Youtube size={22} className="text-rose-500" />,
      url: `https://www.youtube.com/results?search_query=${encodeURIComponent(youtubeQuery)}`,
      action: () => {
        onSendAlyaMessage(`I searched YouTube for "${youtubeQuery}"! Let me know if you want me to play something else! 🎵`);
        triggerFeedback(`YouTube search for "${youtubeQuery}" prepared`);
      },
    },
    {
      name: 'WhatsApp',
      category: 'Messaging',
      icon: <MessageCircle size={22} className="text-emerald-400" />,
      url: 'https://web.whatsapp.com',
      action: () => {
        triggerFeedback('WhatsApp Web intent ready');
      },
    },
    {
      name: 'Instagram',
      category: 'Social',
      icon: <Share2 size={22} className="text-pink-400" />,
      url: 'https://instagram.com',
      action: () => {
        triggerFeedback('Instagram intent ready');
      },
    },
    {
      name: 'Camera / Screen',
      category: 'Tools',
      icon: <Camera size={22} className="text-cyan-400" />,
      action: () => {
        onOpenScreenTools();
      },
    },
  ];

  const triggerFeedback = (msg: string) => {
    setActionFeedback(msg);
    setTimeout(() => setActionFeedback(null), 3500);
  };

  return (
    <div className="w-full h-full flex flex-col justify-between overflow-hidden bg-black/40 backdrop-blur-md p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold font-comfortaa text-white flex items-center gap-1.5">
            Phone Control <span className="text-blue-400 text-xs">Bridge</span>
          </h2>
          <span className="text-[11px] text-slate-300">
            Authorized Android app intents & device automation
          </span>
        </div>
        <div className="flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
          <ShieldCheck size={12} /> Secure Sandbox
        </div>
      </div>

      {actionFeedback && (
        <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 text-xs flex items-center gap-2 animate-fadeIn">
          <Check size={14} className="text-emerald-400" />
          <span>{actionFeedback}</span>
        </div>
      )}

      <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-white/10 text-xs font-semibold">
        {(['apps', 'system', 'notifications', 'automation'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-1.5 rounded-lg capitalize transition-all ${
              activeTab === tab
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto space-y-3 pr-1">
        {activeTab === 'apps' && (
          <div className="space-y-3">
            <div className="glass-card rounded-2xl p-3 border border-rose-500/30 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-white">
                <Youtube size={16} className="text-rose-500" />
                <span>Control YouTube via Alya</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={youtubeQuery}
                    onChange={(e) => setYoutubeQuery(e.target.value)}
                    placeholder="Search video, artist, anime OST..."
                    className="w-full bg-black/40 border border-white/15 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-rose-500"
                  />
                </div>
                <button
                  onClick={() => apps[0].action()}
                  className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1 active:scale-95 transition-all shadow-md"
                >
                  <Play size={12} /> Play
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {apps.map((app) => (
                <button
                  key={app.name}
                  onClick={app.action}
                  className="glass-panel p-3 rounded-2xl border border-white/10 hover:border-pink-500/40 flex items-center gap-3 text-left transition-all active:scale-95 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center group-hover:scale-110 transition-transform">
                    {app.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-white flex items-center gap-1">
                      {app.name} <ExternalLink size={10} className="text-slate-400" />
                    </div>
                    <div className="text-[10px] text-slate-400">{app.category}</div>
                  </div>
                </button>
              ))}
            </div>

            <div className="glass-card rounded-2xl p-3 border border-indigo-500/30 flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Camera size={14} className="text-indigo-400" />
                  <span>Inspect Phone Screen</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Let Alya analyze what's on your screen using AI vision.
                </p>
              </div>
              <button
                onClick={onOpenScreenTools}
                className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1"
              >
                Launch
              </button>
            </div>
          </div>
        )}

        {activeTab === 'system' && (
          <div className="space-y-2">
            <div className="glass-card rounded-2xl p-3 border border-white/10 space-y-3">
              <div className="text-xs font-bold text-white flex items-center gap-2">
                <Sliders size={15} className="text-cyan-400" />
                <span>Device Shortcuts</span>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-white/5">
                <div className="flex items-center gap-2 text-xs text-slate-200">
                  <Flame size={15} className="text-amber-400" />
                  <span>Screen Flashlight</span>
                </div>
                <button
                  onClick={() => triggerFeedback('Screen light boosted')}
                  className="px-3 py-1 rounded-full text-xs font-semibold bg-white/10 hover:bg-white/20 text-white"
                >
                  Toggle
                </button>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-white/5">
                <div className="flex items-center gap-2 text-xs text-slate-200">
                  <Volume2 size={15} className="text-pink-400" />
                  <span>Companion Audio Volume</span>
                </div>
                <span className="text-xs text-pink-300 font-bold">100%</span>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'notifications' && (
          <div className="space-y-2">
            <div className="text-xs text-slate-400 px-1 font-semibold flex items-center gap-1">
              <Bell size={13} className="text-pink-400" />
              <span>Companion Notifications</span>
            </div>
            <div className="glass-card rounded-2xl p-3 border border-pink-500/20 space-y-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-bold text-pink-300">Alya Daily Check-in</span>
                <span className="text-slate-400">08:00 AM</span>
              </div>
              <p className="text-xs text-slate-200">
                "Good morning {userName}! Ready to start today? 🌸"
              </p>
            </div>
          </div>
        )}

        {activeTab === 'automation' && (
          <div className="space-y-2">
            <div className="glass-card rounded-2xl p-3 border border-white/10 space-y-2">
              <h3 className="text-xs font-bold text-white">Daily Companion Routines</h3>
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between p-2 rounded-xl bg-white/5">
                  <div>
                    <div className="font-semibold text-pink-300">Morning Wake-up Check</div>
                    <div className="text-[10px] text-slate-400">08:00 AM</div>
                  </div>
                  <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300">Active</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-2.5 rounded-xl glass-panel-subtle border border-white/5 text-[11px] text-slate-400 flex items-center gap-2">
        <ShieldCheck size={14} className="text-emerald-400 flex-shrink-0" />
        <span>All actions operate with direct user consent. No background tracking.</span>
      </div>
    </div>
  );
};
