import { LanguageMode, CommunicationStyleProfile } from '../types';

// Common Romanized Hindi / Hinglish tokens frequently used in conversational dialogue
const HINGLISH_TOKENS = new Set([
  'kya', 'kyun', 'kaise', 'kaisa', 'kaisi', 'kab', 'kahan', 'kidhar', 'kon', 'kaun',
  'hai', 'hain', 'ho', 'hoon', 'tha', 'thi', 'the', 'hoga', 'hogi', 'hoge',
  'raha', 'rahi', 'rahe', 'kar', 'karo', 'kare', 'karein', 'karna', 'karte', 'karti',
  'mujhe', 'mera', 'meri', 'mere', 'tum', 'tumhara', 'tumhari', 'tumhare', 'aap', 'aapka', 'aapki', 'aapke',
  'hum', 'hamara', 'hamari', 'unhe', 'unka', 'iska', 'uski', 'isko', 'usko',
  'theek', 'accha', 'achha', 'badhiya', 'bohot', 'bahut', 'sahi', 'mast',
  'nahi', 'nahin', 'na', 'haan', 'han', 'bilkul', 'zaroor', 'shukriya', 'dhanyawad',
  'batao', 'bataiye', 'bolo', 'boliye', 'suno', 'sunao', 'dekh', 'dekho',
  'yaar', 'bhai', 'bro', 'dost', 'didi', 'bhaiya',
  'chalo', 'chal', 'aaj', 'kal', 'parson', 'ab', 'abhi', 'tab', 'kabhi',
  'kuch', 'koi', 'sab', 'sabko', 'sabse', 'saath', 'paas', 'dur',
  'baat', 'kaam', 'samajh', 'samjha', 'samjhi', 'pata', 'maloom',
  'din', 'raat', 'subah', 'shaam', 'waqt', 'samay', 'madad', 'zaroorat',
]);

// Devanagari script range
const DEVANAGARI_REGEX = /[\u0900-\u097F]/;

export interface DetectionResult {
  mode: LanguageMode;
  confidence: number;
  hinglishScore: number;
  hasDevanagari: boolean;
  wordCount: number;
  reason: string;
}

export class LanguageEngine {
  /**
   * Detect dominant language mode of a single utterance: 'hindi' | 'hinglish' | 'english' | 'other'
   */
  static detectLanguage(text: string): DetectionResult {
    const clean = (text || '').trim();
    if (!clean) {
      return {
        mode: 'english',
        confidence: 0.5,
        hinglishScore: 0,
        hasDevanagari: false,
        wordCount: 0,
        reason: 'Empty input defaults to English',
      };
    }

    const hasDevanagari = DEVANAGARI_REGEX.test(clean);
    if (hasDevanagari) {
      return {
        mode: 'hindi',
        confidence: 0.95,
        hinglishScore: 0.9,
        hasDevanagari: true,
        wordCount: clean.split(/\s+/).length,
        reason: 'Contains Devanagari script',
      };
    }

    // Split words and sanitize
    const words = clean
      .toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter((w) => w.length > 1);

    if (words.length === 0) {
      return {
        mode: 'english',
        confidence: 0.5,
        hinglishScore: 0,
        hasDevanagari: false,
        wordCount: 0,
        reason: 'No alphabetic words detected',
      };
    }

    let hinglishCount = 0;
    for (const word of words) {
      if (HINGLISH_TOKENS.has(word)) {
        hinglishCount++;
      }
    }

    const hinglishRatio = hinglishCount / words.length;

    // Classification logic
    if (hinglishCount >= 1 && hinglishRatio >= 0.25) {
      // If words are mostly Hindi Romanized or mixed with English
      return {
        mode: 'hinglish',
        confidence: Math.min(1, 0.6 + hinglishRatio * 0.4),
        hinglishScore: hinglishRatio,
        hasDevanagari: false,
        wordCount: words.length,
        reason: `Detected ${hinglishCount} Hinglish markers (${Math.round(hinglishRatio * 100)}% of words)`,
      };
    }

    if (hinglishCount >= 1 && words.length <= 4) {
      // Short phrases like "Kaise ho?", "Kya haal?", "Batao bro"
      return {
        mode: 'hinglish',
        confidence: 0.85,
        hinglishScore: 0.7,
        hasDevanagari: false,
        wordCount: words.length,
        reason: 'Short conversational phrase with Hinglish marker',
      };
    }

    return {
      mode: 'english',
      confidence: 0.85,
      hinglishScore: hinglishRatio,
      hasDevanagari: false,
      wordCount: words.length,
      reason: 'Standard English vocabulary detected',
    };
  }

  /**
   * Determine speech recognition language code to optimize browser STT accuracy.
   * Chrome/Edge performs significantly better for Indian users/Hinglish when set to 'en-IN'.
   */
  static getSTTLanguage(detectedMode: LanguageMode, userPreferred?: string): string {
    if (userPreferred === 'hindi' || detectedMode === 'hindi') {
      return 'hi-IN';
    }
    if (userPreferred === 'hinglish' || detectedMode === 'hinglish') {
      return 'en-IN'; // en-IN handles Hinglish phonetic loanwords best in Web Speech API
    }
    return 'en-US';
  }

  /**
   * Produce dynamic language instructions for AI prompt based on latest message
   * and owner communication history.
   */
  static getPromptInstruction(
    detected: DetectionResult,
    ownerStyle?: Partial<CommunicationStyleProfile>
  ): string {
    const mode = detected.mode;

    if (mode === 'hinglish') {
      return [
        `CRITICAL LANGUAGE & TONE DIRECTIVE:`,
        `- The user is speaking in HINGLISH (a natural blend of Hindi and English, written in Latin alphabet, e.g. "Kya kar rahi ho?", "Bro server issue aa raha hai").`,
        `- You MUST naturally respond in fluent, conversational HINGLISH in the exact same style.`,
        `- Example Hinglish tone: "Main badhiya hoon! Aap batao, sab kaisa chal raha hai?", "Arre waah! Chalo main help karti hoon."`,
        `- Do NOT respond purely in stiff English when the user speaks in Hinglish.`,
        `- Keep the reply warm, natural, and expressive.`,
      ].join('\n');
    }

    if (mode === 'hindi') {
      return [
        `CRITICAL LANGUAGE DIRECTIVE:`,
        `- The user is communicating in HINDI.`,
        `- You MUST respond primarily in fluent, warm, and natural HINDI (or Devanagari / conversational Hindi).`,
        `- Keep your response natural, friendly, and respectful.`,
      ].join('\n');
    }

    return [
      `CRITICAL LANGUAGE DIRECTIVE:`,
      `- The user is communicating in ENGLISH.`,
      `- Respond naturally, warmly, and fluently in ENGLISH.`,
      `- If the user later switches to Hinglish or Hindi, immediately adapt to their language choice.`,
    ].join('\n');
  }

  /**
   * Update communication style profile based on new message
   */
  static updateStyleProfile(
    current: CommunicationStyleProfile | undefined,
    newMessage: string
  ): CommunicationStyleProfile {
    const detection = this.detectLanguage(newMessage);
    const existing: CommunicationStyleProfile = current || {
      dominantLanguage: 'english',
      hinglishAffinity: 0.3,
      hindiAffinity: 0.1,
      englishAffinity: 0.6,
      formality: 'casual',
      preferredPacing: 'natural',
      lastUpdated: new Date().toISOString(),
    };

    const alpha = 0.25; // smoothing factor
    let newHinglish = existing.hinglishAffinity;
    let newHindi = existing.hindiAffinity;
    let newEnglish = existing.englishAffinity;

    if (detection.mode === 'hinglish') {
      newHinglish = Math.min(1, newHinglish + alpha * (1 - newHinglish));
      newEnglish = Math.max(0, newEnglish - alpha * 0.5);
    } else if (detection.mode === 'hindi') {
      newHindi = Math.min(1, newHindi + alpha * (1 - newHindi));
    } else {
      newEnglish = Math.min(1, newEnglish + alpha * (1 - newEnglish));
      newHinglish = Math.max(0, newHinglish - alpha * 0.3);
    }

    const maxScore = Math.max(newHinglish, newHindi, newEnglish);
    const dominant: LanguageMode =
      maxScore === newHinglish
        ? 'hinglish'
        : maxScore === newHindi
        ? 'hindi'
        : 'english';

    return {
      dominantLanguage: dominant,
      hinglishAffinity: Number(newHinglish.toFixed(2)),
      hindiAffinity: Number(newHindi.toFixed(2)),
      englishAffinity: Number(newEnglish.toFixed(2)),
      formality: existing.formality,
      preferredPacing: existing.preferredPacing,
      lastUpdated: new Date().toISOString(),
    };
  }
}
