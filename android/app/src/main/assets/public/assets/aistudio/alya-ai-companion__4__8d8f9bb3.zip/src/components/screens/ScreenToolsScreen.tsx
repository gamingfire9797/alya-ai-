import React, { useState, useRef } from 'react';
import { Scan, Upload, Monitor, Sparkles } from 'lucide-react';
import { ExpressionType } from '../../types';

interface ScreenToolsScreenProps {
  onAnalyzeScreen: (imageBase64: string, prompt: string) => Promise<{ analysis: string; emotion: ExpressionType }>;
}

export const ScreenToolsScreen: React.FC<ScreenToolsScreenProps> = ({ onAnalyzeScreen }) => {
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('What is on my screen? Can you summarize or help me with it?');
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleCaptureScreen = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) {
        const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        const track = stream.getVideoTracks()[0];
        const imageCapture = new (window as any).ImageCapture(track);
        const bitmap = await imageCapture.grabFrame();
        track.stop();
        const canvas = document.createElement('canvas');
        canvas.width = bitmap.width;
        canvas.height = bitmap.height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(bitmap, 0, 0);
        const base64 = canvas.toDataURL('image/png');
        setCapturedImage(base64);
      } else {
        fileInputRef.current?.click();
      }
    } catch {
      fileInputRef.current?.click();
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setCapturedImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    if (!capturedImage) return;
    setAnalyzing(true);
    setAnalysisResult(null);
    try {
      const res = await onAnalyzeScreen(capturedImage, prompt);
      setAnalysisResult(res.analysis);
    } catch {
      setAnalysisResult("I had a little trouble analyzing this screen. Please try again!");
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="w-full h-full flex flex-col justify-between overflow-hidden bg-black/40 backdrop-blur-md p-4 space-y-3">
      <div>
        <h2 className="text-xl font-bold font-comfortaa text-white flex items-center gap-1.5">
          Screen Understanding <span className="text-indigo-400 text-xs">• Gemini AI</span>
        </h2>
        <p className="text-[11px] text-slate-300">
          Capture or upload your phone screen for Alya to inspect & explain
        </p>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileUpload}
      />

      <div className="flex-1 glass-card rounded-3xl p-3 border border-indigo-500/30 flex flex-col items-center justify-center overflow-hidden relative">
        {capturedImage ? (
          <div className="w-full h-full flex flex-col items-center justify-center relative">
            <img
              src={capturedImage}
              alt="Captured screen"
              className="max-h-[30vh] max-w-full rounded-xl object-contain border border-white/20 shadow-md"
              referrerPolicy="no-referrer"
            />
            <button
              onClick={() => {
                setCapturedImage(null);
                setAnalysisResult(null);
              }}
              className="mt-2 text-xs text-rose-400 hover:text-rose-300 underline"
            >
              Clear & Pick another
            </button>
          </div>
        ) : (
          <div className="text-center p-6 space-y-3">
            <div className="w-16 h-16 rounded-full bg-indigo-500/10 border border-indigo-500/30 mx-auto flex items-center justify-center text-indigo-400 shadow-[0_0_15px_rgba(99,102,241,0.25)]">
              <Scan size={32} />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-white">No Screen Capture Yet</h3>
              <p className="text-xs text-slate-400 max-w-[260px] mx-auto">
                Share a screenshot or capture your screen for Alya to analyze with vision AI.
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                onClick={handleCaptureScreen}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md active:scale-95 transition-all"
              >
                <Monitor size={14} /> Capture Screen
              </button>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2 rounded-xl glass-panel-subtle hover:bg-white/10 text-slate-200 text-xs font-semibold flex items-center gap-1.5 active:scale-95 transition-all"
              >
                <Upload size={14} /> Upload Image
              </button>
            </div>
          </div>
        )}

        {analysisResult && (
          <div className="absolute inset-x-3 bottom-3 p-3.5 glass-panel rounded-2xl border border-indigo-400/40 shadow-xl max-h-[35vh] overflow-y-auto animate-fadeIn">
            <div className="flex items-center gap-1.5 text-indigo-300 text-xs font-bold mb-1">
              <Sparkles size={14} />
              <span>Alya's Screen Analysis:</span>
            </div>
            <p className="text-xs text-slate-100 font-quicksand leading-relaxed">
              {analysisResult}
            </p>
          </div>
        )}
      </div>

      {capturedImage && !analysisResult && (
        <div className="glass-panel p-2.5 rounded-2xl border border-white/10 flex items-center gap-2">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Ask Alya about this screen..."
            className="flex-1 bg-transparent text-xs text-white placeholder:text-slate-400 focus:outline-none"
          />
          <button
            onClick={handleAnalyze}
            disabled={analyzing}
            className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-pink-600 text-white text-xs font-bold flex items-center gap-1 shadow-md active:scale-95 transition-all disabled:opacity-50"
          >
            {analyzing ? (
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-white animate-ping" /> Analyzing...
              </span>
            ) : (
              <>
                <Sparkles size={13} /> Ask Alya
              </>
            )}
          </button>
        </div>
      )}

      <div className="text-[10px] text-slate-400 text-center">
        Screen understanding is only invoked when you explicitly capture or upload an image.
      </div>
    </div>
  );
};
