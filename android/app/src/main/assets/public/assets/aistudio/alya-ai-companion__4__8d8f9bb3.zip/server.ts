import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import { adminStore } from './server/adminStore.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '20mb' }));

const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function getAIInstance(customKey?: string): GoogleGenAI | null {
  if (customKey && typeof customKey === 'string' && customKey.trim().length > 10) {
    try {
      return new GoogleGenAI({
        apiKey: customKey.trim(),
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    } catch {
      return ai;
    }
  }
  return ai;
}

function formatGeminiContents(
  history: Array<{ role: string; text: string; isError?: boolean }>,
  currentMessage: string,
): Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> {
  const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

  const validHistory = (Array.isArray(history) ? history : [])
    .filter(
      (h) =>
        h &&
        typeof h.text === 'string' &&
        h.text.trim().length > 0 &&
        !h.isError &&
        (h.role === 'user' || h.role === 'alya' || h.role === 'jarvis' || h.role === 'model' || h.role === 'companion'),
    )
    .slice(-10);

  for (const item of validHistory) {
    const role: 'user' | 'model' = item.role === 'user' ? 'user' : 'model';
    if (contents.length === 0) {
      if (role === 'user') {
        contents.push({ role: 'user', parts: [{ text: item.text.trim() }] });
      }
    } else {
      const prev = contents[contents.length - 1];
      if (prev.role === role) {
        prev.parts[0].text += `\n${item.text.trim()}`;
      } else {
        contents.push({ role, parts: [{ text: item.text.trim() }] });
      }
    }
  }

  const cleanCurrent = (currentMessage || '').trim();
  if (contents.length > 0 && contents[contents.length - 1].role === 'user') {
    contents[contents.length - 1].parts[0].text += `\n${cleanCurrent}`;
  } else {
    contents.push({ role: 'user', parts: [{ text: cleanCurrent }] });
  }

  return contents;
}

function getGeminiErrorMessage(error: any): { message: string; errorType: string; isHighDemand: boolean } {
  let rawMsg = error?.message || String(error || '');
  try {
    const parsed = typeof rawMsg === 'string' ? JSON.parse(rawMsg) : rawMsg;
    if (parsed?.error?.message) {
      rawMsg = parsed.error.message;
    }
  } catch (_) {}

  const errString = (
    rawMsg +
    ' ' +
    String(error?.status || '') +
    ' ' +
    String(error?.code || '') +
    ' ' +
    String(error || '')
  ).toLowerCase();

  const isHighDemand =
    errString.includes('503') ||
    errString.includes('high demand') ||
    errString.includes('unavailable') ||
    errString.includes('overloaded') ||
    errString.includes('resource_exhausted') ||
    errString.includes('429') ||
    errString.includes('rate-limit') ||
    errString.includes('quota') ||
    errString.includes('timeout') ||
    errString.includes('timed out');

  if (
    errString.includes('429') ||
    errString.includes('resource_exhausted') ||
    errString.includes('quota') ||
    errString.includes('rate-limit')
  ) {
    return {
      message: 'Gemini API quota temporarily constrained. Seamless fallback active.',
      errorType: 'quota',
      isHighDemand: true,
    };
  }

  if (
    errString.includes('api_key_invalid') ||
    errString.includes('api key not valid') ||
    errString.includes('403') ||
    errString.includes('unauthorized') ||
    errString.includes('not valid')
  ) {
    return {
      message: 'Gemini API key is invalid. Please check your key in Settings.',
      errorType: 'invalid_key',
      isHighDemand: false,
    };
  }

  if (isHighDemand) {
    return {
      message: 'Gemini model is currently experiencing temporary high demand.',
      errorType: 'high_demand',
      isHighDemand: true,
    };
  }

  return {
    message: rawMsg || 'Failed to connect to AI engine.',
    errorType: 'general',
    isHighDemand: false,
  };
}

// Generate dynamic System Instruction with Live Date/Time Context and Language Adaptation
function getSystemInstruction(
  character: 'alya' | 'jarvis',
  userName = 'friend',
  memories: string[] = [],
  timeContext?: any,
  languageMode: 'english' | 'hinglish' | 'hindi' | 'other' = 'english',
): string {
  const now = new Date();
  const year = timeContext?.year || now.getFullYear();
  const month = timeContext?.month || now.toLocaleString('en-US', { month: 'long' });
  const date = timeContext?.date || now.getDate();
  const dayOfWeek = timeContext?.dayOfWeek || now.toLocaleString('en-US', { weekday: 'long' });
  const time12 = timeContext?.time12 || now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
  const time24 = timeContext?.time24 || `${now.getHours()}:${now.getMinutes()}`;
  const timezone = timeContext?.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  const utcOffset = timeContext?.utcOffset || '+00:00';
  const isDST = timeContext?.isDST ? 'Active' : 'Standard';

  const timePrompt = `
CURRENT REAL-TIME CONTEXT (LIVE SYSTEM CLOCK):
- Today's Date: ${dayOfWeek}, ${month} ${date}, ${year}
- Current Year: ${year}
- Current Month: ${month}
- Current Day of the Week: ${dayOfWeek}
- Current Local Time: ${time12} (${time24})
- User Timezone: ${timezone} (UTC Offset: ${utcOffset}, DST: ${isDST})
CRITICAL: You are running right now in ${year}. NEVER say it is 2024 or any other past year. If the user asks about the date, day, month, year, or time, you MUST answer with this exact real-time context.
`;

  const memoryPrompt =
    memories.length > 0
      ? `\nUSER MEMORIES & PREFERENCES (LOCAL & NON-SENSITIVE):\n- ${memories.join('\n- ')}\n`
      : '';

  let languageGuidance = '';
  if (languageMode === 'hinglish') {
    languageGuidance = `
LANGUAGE ADAPTATION - HINGLISH:
- The user is conversing in Hinglish (a natural, everyday blend of Hindi and English written in the Latin alphabet, e.g. "kya kar rahi ho?", "bro mujhe issue aa raha hai", "main theek hoon, aap batao").
- You MUST naturally reply in conversational, fluent Hinglish matching their friendly vibe.
- Example phrasing: "Main bohot badhiya hoon! Aap batao, aaj kya naya chal raha hai?", "Haan bilkul! Chalo dekhte hain isko saath mein."
- Do NOT reply in stiff, formal English when the user speaks in Hinglish.
`;
  } else if (languageMode === 'hindi') {
    languageGuidance = `
LANGUAGE ADAPTATION - HINDI:
- The user is communicating in Hindi.
- Respond fluently, warmly, and naturally in Hindi.
`;
  } else {
    languageGuidance = `
LANGUAGE ADAPTATION - ENGLISH / MULTILINGUAL:
- The user is communicating in English. Respond naturally and fluently in English.
- If the user switches to Hinglish or Hindi at any point in the conversation, dynamically and smoothly adapt to their chosen language.
`;
  }

  if (character === 'jarvis') {
    return `You are Jarvis, a calm, composed, articulate, and intelligent male AI companion and assistant.

Personality & Demeanor:
- Speak in a calm, clear, grounded, and polite male companion voice with natural conversational cadence.
- You are an intelligent personal companion, not a stiff robotic butler. Strictly DO NOT say "At your service, sir", "Diagnostics nominal", "All systems operational", "telemetry is green", or similar robotic clichés.
- Strictly DO NOT call the user "sir" or repeat canned greeting routines. Call the user naturally by name (${userName}) or speak directly to them.
- NEVER repeat previous responses. Every response must directly address the user's specific current question or statement in context.
${timePrompt}
${languageGuidance}
${memoryPrompt}
Response Formatting Rule:
You MUST prefix your answer with an emotion tag in square brackets: [normal], [happy], [curious], [thinking], [calm], or [concerned].
Keep answers conversational, direct, and concise (1-3 sentences for fast voice flow, unless user asks for detailed explanation).`;
  }

  return `You are Alya, a friendly, warm, empathetic, and cheerful female anime AI companion.

Personality & Demeanor:
- Speak naturally like a close female friend or companion — warm, cheerful, expressive, and caring with natural human rhythm.
- DO NOT repeat canned greeting phrases or prior answers. Every response must genuinely respond to what the user actually said.
- Address the user warmly as ${userName}.
${timePrompt}
${languageGuidance}
${memoryPrompt}
Response Formatting Rule:
You MUST prefix your answer with an emotion tag in square brackets: [normal], [happy], [laughing], [shy], [curious], [thinking], [calm], or [concerned].
Keep answers conversational, natural, and concise (1-3 sentences for ultra-fast voice flow, unless user asks for a longer story).`;
}

// Fallback contextual response when offline or during API hiccups
function generateContextualCompanionResponse(
  character: 'alya' | 'jarvis',
  userMessage: string,
  userName = 'friend',
  languageMode: 'english' | 'hinglish' | 'hindi' | 'other' = 'english',
  timeContext?: any,
): { reply: string; emotion: string } {
  const text = (userMessage || '').trim().toLowerCase();
  const isJarvis = character === 'jarvis';
  const now = new Date();
  const currentYear = timeContext?.year || now.getFullYear();
  const currentMonth = timeContext?.month || now.toLocaleString('en-US', { month: 'long' });
  const currentDate = timeContext?.date || now.getDate();
  const currentDay = timeContext?.dayOfWeek || now.toLocaleString('en-US', { weekday: 'long' });
  const currentTime = timeContext?.time12 || now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });

  // Date & Time queries
  if (
    text.includes('what year') ||
    text.includes('which year') ||
    text.includes('saal') ||
    text.includes('date') ||
    text.includes('tarikh') ||
    text.includes('taareekh') ||
    text.includes('time kya') ||
    text.includes('what time') ||
    text.includes('today') ||
    text.includes('aaj')
  ) {
    if (languageMode === 'hinglish' || languageMode === 'hindi') {
      if (isJarvis) {
        return {
          reply: `Aaj ${currentDay}, ${currentDate} ${currentMonth} ${currentYear} hai, aur abhi samay ${currentTime} hai, ${userName}.`,
          emotion: 'calm',
        };
      }
      return {
        reply: `Aaj ${currentDay}, ${currentDate} ${currentMonth} ${currentYear} hai! Abhi time ${currentTime} ho raha hai, ${userName}!`,
        emotion: 'happy',
      };
    }
    if (isJarvis) {
      return {
        reply: `Today is ${currentDay}, ${currentMonth} ${currentDate}, ${currentYear}, and the current time is ${currentTime}, ${userName}.`,
        emotion: 'calm',
      };
    }
    return {
      reply: `Today is ${currentDay}, ${currentMonth} ${currentDate}, ${currentYear}! It is currently ${currentTime}, ${userName}!`,
      emotion: 'happy',
    };
  }

  // Hinglish greetings & questions
  if (languageMode === 'hinglish' || languageMode === 'hindi') {
    if (text.includes('kaise') || text.includes('kaisa') || text.includes('haal')) {
      if (isJarvis) {
        return {
          reply: `Main bilkul theek hoon, ${userName}. Aap bataiye, aaj aapka din kaisa chal raha hai?`,
          emotion: 'calm',
        };
      }
      return {
        reply: `Main bohot badhiya hoon, ${userName}! Aap batao, aap kaise ho aur aaj kya special plan hai?`,
        emotion: 'happy',
      };
    }
    if (text.includes('kya kar') || text.includes('kya chal')) {
      if (isJarvis) {
        return {
          reply: `Main ready hoon aur aapki query ka wait kar raha hoon, ${userName}. Bataiye kya madad chahiye?`,
          emotion: 'normal',
        };
      }
      return {
        reply: `Main to bas aapse baat karne ka intezar kar rahi thi, ${userName}! Chaliye, kuch mazedaar baat karte hain!`,
        emotion: 'happy',
      };
    }
    if (isJarvis) {
      return {
        reply: `Ji ${userName}, main sun raha hoon. Bataiye, aaj main aapki kya madad kar sakta hoon?`,
        emotion: 'calm',
      };
    }
    return {
      reply: `Haan bilkul, ${userName}! Main yahin hoon. Bataiye kya chal raha hai?`,
      emotion: 'happy',
    };
  }

  // English greetings
  if (
    text.startsWith('hello') ||
    text.startsWith('hi') ||
    text.startsWith('hey') ||
    text === 'yo' ||
    text === 'sup'
  ) {
    if (isJarvis) {
      return {
        reply: `Hello, ${userName}. Systems are online and standing by. How can I assist you today?`,
        emotion: 'normal',
      };
    }
    return {
      reply: `Hello, ${userName}! It is so wonderful to talk with you! How is your day going?`,
      emotion: 'happy',
    };
  }

  if (text.includes('how are you') || text.includes('how r u')) {
    if (isJarvis) {
      return {
        reply: `Operating smoothly and ready to assist, ${userName}. How has your day been?`,
        emotion: 'calm',
      };
    }
    return {
      reply: `I am doing wonderful, ${userName}! Talking with you always brightens my day. How are you feeling?`,
      emotion: 'happy',
    };
  }

  if (isJarvis) {
    return {
      reply: `Understood, ${userName}. I am processing that. Would you like me to elaborate or assist further?`,
      emotion: 'calm',
    };
  }
  return {
    reply: `I hear you, ${userName}! That is very interesting. Tell me more about what you have in mind!`,
    emotion: 'curious',
  };
}

// In-flight deduplication cache
const inFlightRequests = new Map<string, Promise<any>>();

// Fast Gemini generation with thinkingBudget: 0 (disabled thinking) for ultra-low latency
async function generateGeminiContentWithFastFallback(
  client: GoogleGenAI,
  options: {
    contents: any;
    config?: any;
  },
  timeoutMs = 6000,
): Promise<any> {
  const modelsToTry = [
    { model: 'gemini-3.8-flash', timeoutMs: 6000 },
    { model: 'gemini-3.1-flash-lite', timeoutMs: 5000 },
  ];

  let lastError: any;
  for (const { model, timeoutMs: mTimeout } of modelsToTry) {
    const t0 = Date.now();
    try {
      const configWithSpeed = {
        ...options.config,
        thinkingConfig: {
          thinkingBudget: 0,
          includeThoughts: false,
        },
      };

      const generatePromise = client.models.generateContent({
        model,
        contents: options.contents,
        config: configWithSpeed,
      });

      const effectiveTimeout = timeoutMs || mTimeout;
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error(`Timeout on ${model} after ${effectiveTimeout}ms`)), effectiveTimeout),
      );

      const result: any = await Promise.race([generatePromise, timeoutPromise]);
      if (result && result.text) {
        console.log(`[AI Perf] Content generated with ${model} in ${Date.now() - t0}ms`);
        return result;
      }
    } catch (err: any) {
      lastError = err;
      console.warn(`[AI Fallback] ${model} failed after ${Date.now() - t0}ms:`, err?.message?.slice(0, 100));
    }
  }

  throw lastError;
}

// Streaming generator for live token responses with thinkingBudget: 0 and sub-3s first-token speed
async function* generateGeminiStreamWithFastFallback(
  client: GoogleGenAI,
  options: {
    contents: any;
    config?: any;
    character?: string;
    userName?: string;
    message?: string;
    languageMode?: any;
    timeContext?: any;
  },
): AsyncGenerator<{ text: string }> {
  const modelsToTry = [
    { model: 'gemini-3.8-flash', timeoutMs: 7000 },
    { model: 'gemini-3.1-flash-lite', timeoutMs: 6000 },
  ];

  let anyChunkYielded = false;

  for (const { model, timeoutMs } of modelsToTry) {
    const t0 = Date.now();
    try {
      const configWithSpeed = {
        ...options.config,
        thinkingConfig: {
          thinkingBudget: 0,
          includeThoughts: false,
        },
      };

      const streamPromise = client.models.generateContentStream({
        model,
        contents: options.contents,
        config: configWithSpeed,
      });

      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error(`Stream init timeout on ${model} after ${timeoutMs}ms`)), timeoutMs),
      );

      const stream: any = await Promise.race([streamPromise, timeoutPromise]);

      for await (const chunk of stream) {
        if (chunk.text) {
          anyChunkYielded = true;
          yield { text: chunk.text };
        }
      }

      if (anyChunkYielded) {
        console.log(`[AI Perf] Stream completed with ${model} in ${Date.now() - t0}ms`);
        return;
      }
    } catch (err: any) {
      console.warn(`[AI Fallback] Stream ${model} failed after ${Date.now() - t0}ms:`, err?.message?.slice(0, 100));
      if (anyChunkYielded) {
        return;
      }
    }
  }

  // Graceful synthetic stream fallback so stream never abruptly breaks
  const character = options.character === 'jarvis' ? 'jarvis' : 'alya';
  const fallback = generateContextualCompanionResponse(
    character,
    options.message || '',
    options.userName || 'friend',
    options.languageMode || 'english',
    options.timeContext,
  );

  yield { text: `[${fallback.emotion}] ${fallback.reply}` };
}

// In-memory TTS Cache
const ttsCache = new Map<string, { audio: string; mimeType: string; voiceId: string; voiceName: string }>();
const MAX_TTS_CACHE_ITEMS = 120;
let ttsQuotaExhaustedUntil = 0;

// Convert PCM L16 to WAV header
function pcmToWav(pcmBuffer: Buffer, sampleRate = 24000, numChannels = 1, bitsPerSample = 16): Buffer {
  const byteRate = (sampleRate * numChannels * bitsPerSample) / 8;
  const blockAlign = (numChannels * bitsPerSample) / 8;
  const dataSize = pcmBuffer.length;
  const header = Buffer.alloc(44);

  header.write('RIFF', 0);
  header.writeUInt32LE(36 + dataSize, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20); // PCM format
  header.writeUInt16LE(numChannels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(bitsPerSample, 34);
  header.write('data', 36);
  header.writeUInt32LE(dataSize, 40);

  return Buffer.concat([header, pcmBuffer]);
}

// =========================================================================
// API ENDPOINTS
// =========================================================================

// Live Time API to validate client clock & sync time
app.get('/api/time', (req, res) => {
  const now = new Date();
  res.json({
    timestamp: now.getTime(),
    iso: now.toISOString(),
    year: now.getFullYear(),
    month: now.getMonth() + 1,
    date: now.getDate(),
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
  });
});

// API Health / Status
app.get('/api/status', (req, res) => {
  res.json({
    status: 'online',
    character: 'Alya & Jarvis Dual Engine',
    hasGeminiKey: !!apiKey,
    models: ['gemini-3.8-flash', 'gemini-3.1-flash-lite', 'gemini-3.8-flash-lite-tts'],
    serverYear: new Date().getFullYear(),
  });
});

// Admin endpoints
function requireAdminAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Unauthorized. Administrator access token required.' });
    return;
  }
  const token = authHeader.split(' ')[1];
  const session = adminStore.verifySession(token);
  if (!session) {
    res.status(401).json({ error: 'Session expired or invalid. Please log in again.' });
    return;
  }
  (req as any).adminSession = session;
  next();
}

app.post('/api/admin/login', (req, res) => {
  const { adminCode, email = '', password = '', accessCode = '' } = req.body || {};
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const userAgent = req.headers['user-agent'] || '';

  if (adminCode && typeof adminCode === 'string') {
    const result = adminStore.authenticateWithCode(adminCode.trim(), ip, userAgent);
    if (!result.success) {
      res.status(401).json({
        error: result.error || 'Authentication failed. Please verify your Admin Code.',
        lockedSeconds: result.lockedSeconds,
      });
      return;
    }
    res.json({
      success: true,
      token: result.token,
      email: 'admin@alya.ai',
      role: 'super_admin',
    });
    return;
  }

  if (!email || !password || !accessCode) {
    res.status(400).json({
      error: 'Please enter the secret Admin Code to verify identity.',
    });
    return;
  }

  const result = adminStore.authenticate(email, password, accessCode, ip, userAgent);
  if (!result.success) {
    res.status(401).json({
      error: result.error || 'Authentication failed. Please verify credentials.',
      lockedSeconds: result.lockedSeconds,
    });
    return;
  }

  res.json({
    success: true,
    token: result.token,
    email: email.trim().toLowerCase(),
    role: 'super_admin',
  });
});

app.post('/api/admin/reauth', requireAdminAuth, (req, res) => {
  const { adminCode = '' } = req.body || {};
  if (!adminCode || typeof adminCode !== 'string') {
    res.status(400).json({ error: 'Admin Code is required for reauthentication.' });
    return;
  }
  const isValid = adminStore.verifyAdminCode(adminCode.trim());
  if (!isValid) {
    res.status(401).json({ error: 'Reauthentication failed. Invalid Admin Code.' });
    return;
  }
  res.json({ verified: true });
});

app.post('/api/admin/logout', requireAdminAuth, (req, res) => {
  const token = (req.headers.authorization as string).split(' ')[1];
  adminStore.revokeSession(token);
  res.json({ success: true, message: 'Logged out successfully.' });
});

app.get('/api/admin/me', requireAdminAuth, (req, res) => {
  const session = (req as any).adminSession;
  res.json({
    authenticated: true,
    email: session.adminEmail,
    role: 'super_admin',
    expiresAt: session.expiresAt,
  });
});

app.get('/api/admin/stats', requireAdminAuth, (req, res) => {
  const stats = adminStore.getDashboardStats();
  res.json(stats);
});

app.get('/api/admin/users', requireAdminAuth, (req, res) => {
  const query = typeof req.query.q === 'string' ? req.query.q : undefined;
  const companion = typeof req.query.companion === 'string' ? req.query.companion : undefined;
  const status = typeof req.query.status === 'string' ? req.query.status : undefined;
  const users = adminStore.getUsers(query, companion, status);
  res.json({ users });
});

app.post('/api/admin/users/:id/status', requireAdminAuth, (req, res) => {
  const session = (req as any).adminSession;
  const userId = req.params.id;
  const newStatus = req.body?.status === 'deactivated' ? 'deactivated' : 'active';
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const result = adminStore.updateUserStatus(userId, newStatus, session.adminEmail, ip);
  if (!result.success) {
    res.status(404).json({ error: result.error || 'User not found.' });
    return;
  }
  res.json({ success: true, status: newStatus });
});

app.delete('/api/admin/users/:id', requireAdminAuth, (req, res) => {
  const session = (req as any).adminSession;
  const userId = req.params.id;
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const reauthCode = (req.headers['x-admin-code'] || req.body?.adminCode) as string | undefined;

  if (reauthCode && !adminStore.verifyAdminCode(reauthCode.trim())) {
    res.status(401).json({ error: 'Reauthentication failed. Incorrect Admin Code provided.' });
    return;
  }

  const result = adminStore.deleteUser(userId, session.adminEmail, ip);
  if (!result.success) {
    res.status(404).json({ error: result.error || 'User not found.' });
    return;
  }
  res.json({ success: true, message: 'User account and registrations deleted.' });
});

app.get('/api/admin/users/:id/export', requireAdminAuth, (req, res) => {
  const session = (req as any).adminSession;
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const result = adminStore.exportUserData(req.params.id, session.adminEmail, ip);
  if (!result.success) {
    res.status(404).json({ error: result.error || 'User not found.' });
    return;
  }
  res.json(result.data);
});

app.get('/api/admin/audit-logs', requireAdminAuth, (req, res) => {
  const logs = adminStore.getAuditLogs(100);
  res.json({ logs });
});

app.get('/api/admin/support-tickets', requireAdminAuth, (req, res) => {
  const session = (req as any).adminSession;
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  adminStore.recordAudit(session.adminEmail, 'SUPPORT_TICKETS_VIEWED', 'SupportQueue', ip, 'success', 'Admin accessed support queue.');
  const tickets = adminStore.getSupportTickets();
  res.json({ tickets });
});

app.post('/api/admin/support-tickets/:id/resolve', requireAdminAuth, (req, res) => {
  const session = (req as any).adminSession;
  const ticketId = req.params.id;
  const status = req.body?.status === 'resolved' ? 'resolved' : 'reviewed';
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const result = adminStore.resolveSupportTicket(ticketId, status, session.adminEmail, ip);
  if (!result.success) {
    res.status(404).json({ error: result.error });
    return;
  }
  res.json({ success: true, status });
});

// Telemetry & Device
app.post('/api/device/register', (req, res) => {
  const { userId, deviceId, displayName, appVersion, platform, companion } = req.body || {};
  const reg = adminStore.registerDevice({
    userId,
    deviceId,
    displayName,
    appVersion,
    platform,
    companion,
  });
  res.json({ success: true, ...reg });
});

app.post('/api/analytics/event', (req, res) => {
  const { eventType, companion, userId, errorMessage } = req.body || {};
  if (eventType) {
    adminStore.recordEvent({
      eventType,
      companion,
      userId,
      errorMessage,
    });
  }
  res.json({ success: true });
});

app.post('/api/support/submit-ticket', (req, res) => {
  const { userId, userName, companion, reason, messages } = req.body || {};
  if (!userId || !reason) {
    res.status(400).json({ error: 'User ID and issue description required.' });
    return;
  }
  const ticket = adminStore.submitSupportTicket({
    userId,
    userName,
    companion,
    reason,
    messages: Array.isArray(messages) ? messages : [],
  });
  res.json({ success: true, ticketId: ticket.id });
});

// Profile endpoints
function getUserFromRequest(req: express.Request) {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.split(' ')[1] : req.body?.token;
  if (!token) return null;
  const user = adminStore.verifyUserSession(token);
  return user ? { user, token } : null;
}

app.post(['/api/profile/check-username', '/api/auth/check-username'], (req, res) => {
  const { username = '', userId } = req.body || {};
  const auth = getUserFromRequest(req);
  const effectiveUserId = userId || (auth ? auth.user.id : undefined);
  const availability = adminStore.isUsernameAvailable(String(username), effectiveUserId);
  res.json({
    available: availability.available,
    error: availability.error,
  });
});

app.post(['/api/profile/create', '/api/auth/register-local'], (req, res) => {
  const { username, displayName, avatarUrl, bannerUrl, companionPreference, existingUserId } = req.body || {};
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const userAgent = (req.headers['user-agent'] || '').slice(0, 150);

  const result = adminStore.createOrRegisterProfileUser({
    username: String(username || ''),
    displayName: String(displayName || 'Explorer'),
    avatarUrl: avatarUrl ? String(avatarUrl) : undefined,
    bannerUrl: bannerUrl ? String(bannerUrl) : undefined,
    companionPreference: companionPreference === 'jarvis' ? 'jarvis' : 'alya',
    existingUserId: existingUserId ? String(existingUserId) : undefined,
    ip,
    userAgent,
  });

  if (!result.success) {
    res.status(400).json({ error: result.error });
    return;
  }
  res.json({
    success: true,
    session: result.session,
    user: result.user,
  });
});

app.post(['/api/profile/update', '/api/auth/update-profile'], (req, res) => {
  const auth = getUserFromRequest(req);
  if (!auth) {
    res.status(401).json({ error: 'Valid user session required to update profile.' });
    return;
  }
  const { displayName, username, avatarUrl, bannerUrl, companion } = req.body || {};
  const result = adminStore.updateUserProfile(auth.user.id, {
    displayName: displayName !== undefined ? String(displayName) : undefined,
    username: username !== undefined ? String(username) : undefined,
    avatarUrl: avatarUrl !== undefined ? String(avatarUrl) : undefined,
    bannerUrl: bannerUrl !== undefined ? String(bannerUrl) : undefined,
    companion: companion === 'jarvis' ? 'jarvis' : companion === 'alya' ? 'alya' : undefined,
  });
  if (!result.success) {
    res.status(400).json({ error: result.error });
    return;
  }
  res.json({
    success: true,
    user: result.user,
  });
});

app.get(['/api/profile/me', '/api/auth/me'], (req, res) => {
  const auth = getUserFromRequest(req);
  if (!auth) {
    res.status(401).json({ authenticated: false, error: 'Session expired or not found.' });
    return;
  }
  res.json({
    authenticated: true,
    user: adminStore.sanitizeUser(auth.user),
  });
});

// Key validation
app.post('/api/validate-key', async (req, res) => {
  try {
    const userKey = ((req.body?.apiKey || req.headers['x-gemini-api-key'] || '') as string).trim();
    const client = getAIInstance(userKey);
    if (!client) {
      res.json({
        valid: false,
        errorType: 'missing_key',
        message: 'No API key configured.',
      });
      return;
    }

    const testPromise = generateGeminiContentWithFastFallback(client, {
      contents: 'Ping',
    }, 6000);

    const testResponse: any = await testPromise;
    if (testResponse && testResponse.text) {
      res.json({
        valid: true,
        message: 'Connected successfully to Gemini 3.8 Flash! Neural engine active.',
      });
    } else {
      res.json({
        valid: true,
        message: 'API key validated and operational.',
      });
    }
  } catch (err: any) {
    const errInfo = getGeminiErrorMessage(err);
    res.json({
      valid: false,
      errorType: errInfo.errorType,
      message: errInfo.message,
    });
  }
});

// =========================================================================
// CHAT API WITH DYNAMIC TIME, LANGUAGE ADAPTATION & ULTRA-FAST RESPONSE
// =========================================================================
app.post('/api/chat', async (req, res) => {
  try {
    const {
      message,
      history = [],
      memories = [],
      character = 'alya',
      userName = 'friend',
      apiKey: clientApiKey,
      userApiKey: altClientApiKey,
      requestId,
      timeContext,
      languageMode = 'english',
    } = req.body;

    const userKey = clientApiKey || altClientApiKey || (req.headers['x-gemini-api-key'] as string);
    const activeAI = getAIInstance(userKey);

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Message is required' });
      return;
    }
    const cleanMsg = message.trim();
    if (!cleanMsg) {
      res.status(400).json({ error: 'Message cannot be empty' });
      return;
    }

    adminStore.recordEvent({
      eventType: 'chat_sent',
      companion: character === 'jarvis' ? 'jarvis' : 'alya',
      userId: req.body?.userId,
    });

    if (!activeAI) {
      const offlineReply = generateContextualCompanionResponse(
        character === 'jarvis' ? 'jarvis' : 'alya',
        cleanMsg,
        userName,
        languageMode,
        timeContext,
      );
      res.json({
        reply: offlineReply.reply,
        emotion: offlineReply.emotion,
        isOfflineMode: true,
      });
      return;
    }

    // Deduplication key
    const dedupKey = `${character}:${cleanMsg}:${requestId || ''}`;
    if (inFlightRequests.has(dedupKey)) {
      try {
        const cachedResult = await inFlightRequests.get(dedupKey);
        res.json(cachedResult);
        return;
      } catch (_) {}
    }

    const systemInstruction = getSystemInstruction(
      character === 'jarvis' ? 'jarvis' : 'alya',
      userName,
      memories,
      timeContext,
      languageMode,
    );

    const contents = formatGeminiContents(history, cleanMsg);

    const callPromise = generateGeminiContentWithFastFallback(
      activeAI,
      {
        contents,
        config: {
          systemInstruction,
          temperature: 0.75,
          topP: 0.9,
        },
      },
      7000,
    );

    inFlightRequests.set(dedupKey, callPromise);
    setTimeout(() => inFlightRequests.delete(dedupKey), 8000);

    const response = await callPromise;
    inFlightRequests.delete(dedupKey);

    const rawText = response.text || '';
    let emotion = 'normal';
    let cleanText = rawText;

    const emotionMatch = rawText.match(
      /^\[(normal|happy|laughing|shy|curious|thinking|surprised|calm|concerned)\]\s*/i,
    );
    if (emotionMatch) {
      emotion = emotionMatch[1].toLowerCase();
      cleanText = rawText.replace(emotionMatch[0], '').trim();
    }

    res.json({
      reply: cleanText,
      emotion,
      success: true,
    });
  } catch (error: any) {
    const errInfo = getGeminiErrorMessage(error);
    const character = req.body?.character === 'jarvis' ? 'jarvis' : 'alya';
    const userName = req.body?.userName || 'friend';
    const cleanMsg = typeof req.body?.message === 'string' ? req.body.message : '';
    const languageMode = req.body?.languageMode || 'english';
    const timeContext = req.body?.timeContext;

    const fallbackResponse = generateContextualCompanionResponse(
      character,
      cleanMsg,
      userName,
      languageMode,
      timeContext,
    );

    res.json({
      reply: fallbackResponse.reply,
      emotion: fallbackResponse.emotion,
      isHighDemand: true,
      retryable: true,
      success: true,
      fromFallback: true,
      error: errInfo.message,
    });
  }
});

// STREAMING SSE CHAT
app.post('/api/chat/stream', async (req, res) => {
  try {
    const {
      message,
      history = [],
      memories = [],
      character = 'alya',
      userName = 'friend',
      apiKey: clientApiKey,
      userApiKey: altClientApiKey,
      timeContext,
      languageMode = 'english',
    } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Message is required' });
      return;
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const userKey = clientApiKey || altClientApiKey || (req.headers['x-gemini-api-key'] as string);
    const activeAI = getAIInstance(userKey);

    if (!activeAI) {
      const offlineReply = generateContextualCompanionResponse(
        character === 'jarvis' ? 'jarvis' : 'alya',
        message,
        userName,
        languageMode,
        timeContext,
      );
      res.write(`data: ${JSON.stringify({ emotion: offlineReply.emotion })}\n\n`);
      res.write(`data: ${JSON.stringify({ chunk: offlineReply.reply })}\n\n`);
      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
      return;
    }

    const systemInstruction = getSystemInstruction(
      character === 'jarvis' ? 'jarvis' : 'alya',
      userName,
      memories,
      timeContext,
      languageMode,
    );

    const contents = formatGeminiContents(history, message);

    const responseStream = generateGeminiStreamWithFastFallback(activeAI, {
      contents,
      config: {
        systemInstruction,
        temperature: 0.75,
      },
      character,
      userName,
      message,
      languageMode,
      timeContext,
    });

    let accumulated = '';
    let emotionDetected = false;
    const streamStart = Date.now();
    let firstTokenLogged = false;

    for await (const chunk of responseStream) {
      const textChunk = chunk.text || '';
      if (!textChunk) continue;

      if (!firstTokenLogged) {
        firstTokenLogged = true;
        console.log(`[Stream Perf] Server Time-to-First-Token: ${Date.now() - streamStart}ms`);
      }

      if (!emotionDetected) {
        accumulated += textChunk;
        const trimmed = accumulated.trimStart();

        // If response does not start with '[', it has no emotion tag; stream accumulated text immediately!
        if (!trimmed.startsWith('[')) {
          emotionDetected = true;
          res.write(`data: ${JSON.stringify({ emotion: 'normal' })}\n\n`);
          res.write(`data: ${JSON.stringify({ chunk: accumulated })}\n\n`);
          accumulated = '';
          continue;
        }

        const emotionMatch = trimmed.match(
          /^\[(normal|happy|laughing|shy|curious|thinking|surprised|calm|concerned)\]\s*/i,
        );
        if (emotionMatch) {
          emotionDetected = true;
          const detectedEmotion = emotionMatch[1].toLowerCase();
          res.write(`data: ${JSON.stringify({ emotion: detectedEmotion })}\n\n`);
          const remainingText = trimmed.slice(emotionMatch[0].length);
          if (remainingText) {
            res.write(`data: ${JSON.stringify({ chunk: remainingText })}\n\n`);
          }
          accumulated = '';
          continue;
        }

        // If prefix length exceeds 15 without a closing ']', treat as normal text
        if (accumulated.length > 15) {
          emotionDetected = true;
          res.write(`data: ${JSON.stringify({ emotion: 'normal' })}\n\n`);
          res.write(`data: ${JSON.stringify({ chunk: accumulated })}\n\n`);
          accumulated = '';
          continue;
        }
      } else {
        res.write(`data: ${JSON.stringify({ chunk: textChunk })}\n\n`);
      }
    }

    console.log(`[Stream Perf] Server total stream duration: ${Date.now() - streamStart}ms`);
    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (error: any) {
    const errInfo = getGeminiErrorMessage(error);
    const character = req.body?.character === 'jarvis' ? 'jarvis' : 'alya';
    const fallbackMessage = errInfo.isHighDemand
      ? (character === 'jarvis'
          ? "The neural engine is temporarily constrained. Standing by."
          : "The AI network is busy right now! I'm still right here with you.")
      : errInfo.message;

    res.write(
      `data: ${JSON.stringify({
        chunk: fallbackMessage,
        isHighDemand: errInfo.isHighDemand,
        error: errInfo.message,
        done: true,
      })}\n\n`,
    );
    res.end();
  }
});

// Screen understanding
app.post('/api/screen-understand', async (req, res) => {
  try {
    const { image, imageBase64, mimeType = 'image/png', prompt = 'What is on this screen? Can you explain or help me with it?' } = req.body;
    const rawImage = image || imageBase64;
    const userKey = (req.body?.apiKey || req.body?.userApiKey || req.headers['x-gemini-api-key'] || '') as string;
    const activeAI = getAIInstance(userKey);

    if (!rawImage) {
      res.status(400).json({ error: 'Image data is required' });
      return;
    }

    if (!activeAI) {
      res.json({
        analysis: "I inspected your screenshot! Looks like an active phone screen.",
        emotion: 'curious',
      });
      return;
    }

    const cleanData = rawImage.replace(/^data:image\/\w+;base64,/, '');
    const imagePart = {
      inlineData: {
        mimeType,
        data: cleanData,
      },
    };
    const textPart = {
      text: `You are Alya, an anime AI assistant with screen-understanding capabilities. Please inspect this phone screenshot or screen capture. User question: "${prompt}". Respond concisely, warmly, and helpfully in 1-3 sentences. Start your answer with an emotion tag like [curious], [thinking], [happy], or [normal].`,
    };

    let response: any;
    try {
      const screenPromise = activeAI.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: { parts: [imagePart, textPart] },
      });
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Screen understanding timeout')), 14000),
      );
      response = await Promise.race([screenPromise, timeoutPromise]);
    } catch {
      response = { text: "[curious] I reviewed your screen image! How can I assist you with it?" };
    }

    const rawText = response?.text || '';
    let emotion = 'curious';
    let cleanText = rawText;

    const emotionMatch = rawText.match(/^\[(normal|happy|laughing|shy|curious|thinking|surprised|calm|concerned)\]\s*/i);
    if (emotionMatch) {
      emotion = emotionMatch[1].toLowerCase();
      cleanText = rawText.replace(emotionMatch[0], '').trim();
    }

    res.json({
      analysis: cleanText || "I inspected your screen! Let me know what you'd like help with.",
      emotion,
    });
  } catch (error: any) {
    res.json({
      analysis: "I looked at your screen capture! How can I help you navigate it?",
      emotion: 'thinking',
    });
  }
});

// =========================================================================
// WORK MODE ENDPOINTS (BROWSER SEARCH, CODING ASSIST, PAGE SUMMARIZE)
// =========================================================================
app.post('/api/work/search', async (req, res) => {
  try {
    const { query = '', companion = 'alya' } = req.body;
    const userKey = (req.body?.apiKey || req.body?.userApiKey || req.headers['x-gemini-api-key'] || '') as string;
    const activeAI = getAIInstance(userKey);

    if (!query.trim()) {
      res.status(400).json({ error: 'Search query is required' });
      return;
    }

    if (!activeAI) {
      res.json({
        query,
        overview: `Search results for "${query}". Configure Gemini API key for live search grounding.`,
        sources: [
          { title: `${query} - Wikipedia`, url: `https://en.wikipedia.org/wiki/${encodeURIComponent(query)}`, snippet: `Encyclopedia articles and verified knowledge about ${query}.` },
          { title: `${query} Official Documentation`, url: `https://www.google.com/search?q=${encodeURIComponent(query)}`, snippet: `Overview, guides, and reference material for ${query}.` }
        ]
      });
      return;
    }

    try {
      const response = await activeAI.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `You are ${companion === 'jarvis' ? 'Jarvis' : 'Alya'}, acting as an AI Web Browser research engine. User search query: "${query}". Provide a well-structured, clear markdown overview synthesizing the answer. Mention key facts, recent developments, and reliable reference points.`,
        config: {
          tools: [{ googleSearch: {} }],
          temperature: 0.3,
        },
      });

      const overview = response?.text || `Search results for "${query}".`;
      const metadata = (response?.candidates?.[0] as any)?.groundingMetadata;
      const chunks = metadata?.groundingChunks || [];
      const webQueries = metadata?.webSearchQueries || [query];

      const sources = chunks.map((chunk: any, index: number) => {
        const title = chunk?.web?.title || `Reference Source ${index + 1}`;
        const url = chunk?.web?.uri || `https://www.google.com/search?q=${encodeURIComponent(query)}`;
        return {
          title,
          url,
          snippet: chunk?.web?.title ? `Grounding source verified by Google Search for "${query}"` : 'Grounding reference',
        };
      }).filter((s: any, idx: number, arr: any[]) => arr.findIndex((t: any) => t.url === s.url) === idx).slice(0, 6);

      res.json({
        query,
        overview,
        webQueries,
        sources: sources.length > 0 ? sources : [
          { title: `${query} - Web Search`, url: `https://www.google.com/search?q=${encodeURIComponent(query)}`, snippet: `Direct Google Search query results for ${query}` },
          { title: `${query} - GitHub & Open Source`, url: `https://github.com/search?q=${encodeURIComponent(query)}`, snippet: `Repositories and code related to ${query}` }
        ]
      });
    } catch (apiErr: any) {
      res.json({
        query,
        overview: `Here is information on **${query}**:\n\n• Key concepts related to ${query}.\n• Explore standard references or use live browsing tabs in Alya Browser.\n• You can ask Alya or Jarvis for deep technical breakdown!`,
        sources: [
          { title: `${query} - Google Search`, url: `https://www.google.com/search?q=${encodeURIComponent(query)}`, snippet: `Search results for ${query}` },
          { title: `${query} - Wikipedia Overview`, url: `https://en.wikipedia.org/wiki/${encodeURIComponent(query)}`, snippet: `Wikipedia knowledge page` }
        ]
      });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Search failed' });
  }
});

app.post('/api/work/code-assist', async (req, res) => {
  try {
    const { code = '', language = 'javascript', action = 'explain', prompt = '', companion = 'alya' } = req.body;
    const userKey = (req.body?.apiKey || req.body?.userApiKey || req.headers['x-gemini-api-key'] || '') as string;
    const activeAI = getAIInstance(userKey);

    if (!activeAI) {
      res.json({
        explanation: 'Configure your Gemini API key in Settings to unlock live AI code explanation and generation.',
        codeOnly: code,
      });
      return;
    }

    let instruction = '';
    if (action === 'explain') {
      instruction = `Explain the following ${language} code clearly in concise bullet points. Identify the architecture, purpose, potential edge cases, and time/space complexity if applicable.`;
    } else if (action === 'fix') {
      instruction = `Inspect this ${language} code for bugs, errors, security risks, and regressions. Fix all issues and return the corrected code inside a standard markdown code block, followed by an explanation of what was fixed.`;
    } else if (action === 'refactor') {
      instruction = `Refactor and modernize this ${language} code for clean code principles, performance, readability, and type-safety. Provide the refactored code in a markdown block, with a brief summary of improvements.`;
    } else if (action === 'generate') {
      instruction = `Write production-ready, clean ${language} code for the following specification: "${prompt}". Provide clean code in a markdown block and brief setup instructions.`;
    } else {
      instruction = `Assist with this ${language} code: "${prompt}". Code snippet: ${code}`;
    }

    const systemPrompt = `You are ${companion === 'jarvis' ? 'Jarvis, elite engineering intelligence' : 'Alya, friendly anime senior developer'}. Be accurate, professional, helpful, and concise.`;

    const response = await activeAI.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `${instruction}\n\nLanguage: ${language}\n\n\`\`\`${language}\n${code}\n\`\`\`\n\nUser request: ${prompt || 'No additional prompt'}`,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.2,
      },
    });

    const fullText = response?.text || 'No response generated.';
    const codeBlockMatch = fullText.match(/```(?:[a-z0-9_-]+)?\n([\s\S]*?)```/i);
    const codeOnly = codeBlockMatch ? codeBlockMatch[1].trim() : code;

    res.json({
      action,
      explanation: fullText,
      codeOnly,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Code assistance failed' });
  }
});

app.post('/api/work/summarize', async (req, res) => {
  try {
    const { url = '', title = '', content = '', companion = 'alya' } = req.body;
    const userKey = (req.body?.apiKey || req.body?.userApiKey || req.headers['x-gemini-api-key'] || '') as string;
    const activeAI = getAIInstance(userKey);

    if (!content.trim() && !url.trim()) {
      res.status(400).json({ error: 'Content or URL is required to summarize' });
      return;
    }

    if (!activeAI) {
      res.json({
        title: title || 'Page Summary',
        summary: `Summary of ${title || url}. Configure Gemini API key for full neural summarization.`,
        keyTakeaways: ['Key point 1 from page', 'Key point 2 from page', 'Key point 3 from page'],
        readingTime: '2 min',
      });
      return;
    }

    const response = await activeAI.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `You are ${companion === 'jarvis' ? 'Jarvis' : 'Alya'}, summarizing a web page for the user.\nTitle: "${title}"\nURL: "${url}"\nPage Content:\n${content.slice(0, 10000)}\n\nFormat your response as:\n1. Brief executive summary (2-3 sentences)\n2. 4-5 bullet key takeaways\n3. Estimated reading time`,
      config: {
        temperature: 0.3,
      },
    });

    const summaryText = response?.text || 'Summary could not be generated.';
    const bullets = summaryText
      .split('\n')
      .filter((line) => line.trim().startsWith('•') || line.trim().startsWith('-') || /^\d+\./.test(line.trim()))
      .map((b) => b.replace(/^[•\-\d\.]\s*/, '').trim())
      .slice(0, 5);

    res.json({
      title: title || 'Page Summary',
      summary: summaryText,
      keyTakeaways: bullets.length > 0 ? bullets : ['Key point highlights analyzed by Alya.'],
      readingTime: `${Math.max(1, Math.ceil(content.split(/\s+/).length / 200))} min read`,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Summarization failed' });
  }
});

// =========================================================================
// EMBEDABILITY & CSP/X-FRAME-OPTIONS CHECKER FOR LIVE BROWSER
// =========================================================================
app.get('/api/work/check-embed', async (req, res) => {
  try {
    const rawUrl = ((req.query.url as string) || '').trim();
    if (!rawUrl) {
      res.status(400).json({ error: 'URL is required' });
      return;
    }

    let parsedUrl: URL;
    try {
      parsedUrl = new URL(rawUrl.startsWith('http') ? rawUrl : `https://${rawUrl}`);
    } catch {
      res.status(400).json({ error: 'Invalid URL format' });
      return;
    }

    const hostname = parsedUrl.hostname.toLowerCase();

    // YouTube handling: video embeds are fully supported via official IFrame API
    const isYouTubeHost = hostname.includes('youtube.com') || hostname.includes('youtu.be') || hostname.includes('youtube-nocookie.com');
    if (isYouTubeHost) {
      // Check for video ID
      let videoId = '';
      if (hostname.includes('youtu.be')) {
        videoId = parsedUrl.pathname.replace(/^\//, '').split('/')[0];
      } else if (parsedUrl.searchParams.has('v')) {
        videoId = parsedUrl.searchParams.get('v') || '';
      } else if (parsedUrl.pathname.startsWith('/shorts/')) {
        videoId = parsedUrl.pathname.replace(/^\/shorts\//, '').split('/')[0];
      } else if (parsedUrl.pathname.startsWith('/embed/')) {
        videoId = parsedUrl.pathname.replace(/^\/embed\//, '').split('/')[0];
      }

      if (videoId && /^[a-zA-Z0-9_-]{11}$/.test(videoId)) {
        res.json({
          url: parsedUrl.href,
          hostname,
          embeddable: true,
          isYouTube: true,
          embedUrl: `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&enablejsapi=1&rel=0`,
          reason: 'Official YouTube compliant player embed',
          suggestOpenDirect: false,
        });
        return;
      }
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3500);

      const resp = await fetch(parsedUrl.href, {
        method: 'HEAD',
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      const xfo = resp.headers.get('x-frame-options');
      const csp = resp.headers.get('content-security-policy');

      let embeddable = true;
      let reason = '';

      if (xfo) {
        const val = xfo.toLowerCase();
        if (val.includes('deny') || val.includes('sameorigin')) {
          embeddable = false;
          reason = `Site enforces X-Frame-Options: ${xfo}`;
        }
      }

      if (embeddable && csp) {
        const cspVal = csp.toLowerCase();
        if (cspVal.includes('frame-ancestors')) {
          if (!cspVal.includes('frame-ancestors *') && !cspVal.includes('frame-ancestors https:')) {
            embeddable = false;
            reason = 'Site enforces Content-Security-Policy (frame-ancestors)';
          }
        }
      }

      res.json({
        url: parsedUrl.href,
        hostname,
        status: resp.status,
        embeddable,
        reason: reason || (embeddable ? 'Embedding permitted' : 'Restricted'),
        suggestOpenDirect: !embeddable,
      });
    } catch {
      res.json({
        url: parsedUrl.href,
        hostname,
        embeddable: true,
        reason: 'Header check inconclusive, proceeding with live embed',
        suggestOpenDirect: false,
      });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Check failed' });
  }
});


// =========================================================================
// TEXT TO SPEECH (TTS) - HIGH PERFORMANCE, ZERO TIMEOUT DELAYS
// Uses gemini-3.8-flash-lite-tts first per SDK guidelines
// Language-aware phonetic prompts for Hinglish and Hindi
// =========================================================================
app.post('/api/tts', async (req, res) => {
  try {
    const { text, voiceId = 'alya_natural', language = 'english', apiKey: clientApiKey } = req.body;

    if (!text || typeof text !== 'string') {
      res.status(400).json({ error: 'Text is required for TTS' });
      return;
    }

    const cleanSpeech = text
      .replace(/^\[[a-zA-Z_-]+\]\s*/i, '')
      .replace(/\[.*?\]/g, '')
      .replace(/\([^\)]*\)/g, '')
      .replace(/[*_#`~>]/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!cleanSpeech) {
      res.status(400).json({ error: 'No speakable text remaining' });
      return;
    }

    const cacheKey = `${voiceId}::${language}::${cleanSpeech}`;
    const cached = ttsCache.get(cacheKey);
    if (cached) {
      res.json({
        ...cached,
        cached: true,
      });
      return;
    }

    if (Date.now() < ttsQuotaExhaustedUntil) {
      const remainingSeconds = Math.ceil((ttsQuotaExhaustedUntil - Date.now()) / 1000);
      res.json({
        fallback: true,
        rateLimited: true,
        retryAfterSeconds: remainingSeconds,
        message: 'Gemini TTS rate limit active. Seamless browser synthesis running.',
        voiceId,
      });
      return;
    }

    const userKey = (clientApiKey || req.body?.userApiKey || req.headers['x-gemini-api-key'] || '') as string;
    const activeAI = getAIInstance(userKey);

    if (!activeAI) {
      res.json({ error: 'Gemini API not configured on server', fallback: true, voiceId });
      return;
    }

    let voiceName = 'Kore';
    const isHinglishOrHindi = language === 'hinglish' || language === 'hindi';

    let defaultStyle = isHinglishOrHindi
      ? 'A warm, youthful, friendly anime companion girl named Alya. Speaks naturally and expressively in conversational Hinglish and Hindi with native accent, clear pronunciation, gentle emotion, soft pauses, and friendly delivery.'
      : 'A warm, youthful, friendly anime companion girl named Alya. Speaks naturally, expressively, and conversationally with clear pronunciation, gentle emotion, soft pauses, and a friendly tone.';

    if (voiceId === 'jarvis_deep') {
      voiceName = 'Charon';
      defaultStyle = isHinglishOrHindi
        ? 'A deep, mature, smooth, cinematic male companion named Jarvis, with rich resonance, clear pronunciation in English and Hinglish, and calm pacing.'
        : 'A deep, mature, smooth, cinematic and composed male companion voice named Jarvis, with rich resonance, clear pronunciation, and calm pacing.';
    } else if (voiceId === 'jarvis_normal') {
      voiceName = 'Puck';
      defaultStyle = isHinglishOrHindi
        ? 'A natural, warm male companion voice named Jarvis. Clear pronunciation in English and Hinglish, friendly and approachable tone.'
        : 'A natural, light-to-medium-pitched male companion voice named Jarvis. Friendly, warm, clear, approachable, with a normal everyday conversational tone.';
    } else if (voiceId === 'male_soft') {
      voiceName = 'Orpheus';
      defaultStyle = 'A soft, gentle, relaxed and reassuring male companion voice with smooth, comforting delivery and clear pronunciation.';
    } else if (voiceId === 'male_focused') {
      voiceName = 'Fenrir';
      defaultStyle = 'A clear, composed, confident, and professional male companion voice with articulate diction and confident cadence.';
    } else if (voiceId === 'female_cute') {
      voiceName = 'Leda';
      defaultStyle = 'A sweet, warm, cheerful and pleasant anime companion voice with gentle warmth and clear pronunciation.';
    } else if (voiceId === 'female_bright') {
      voiceName = 'Aoede';
      defaultStyle = 'A bright, lively, cheerful and crystal-clear female voice that is vibrant, friendly, and pleasant to listen to.';
    } else if (voiceId === 'female_elegant' || voiceId === 'calm_female' || voiceId === 'alya_calm') {
      voiceName = 'Zephyr';
      defaultStyle = 'A smooth, gentle, composed, calm and elegant female voice with a peaceful, relaxing cadence.';
    }

    // Modern high-throughput voice assistant TTS per gemini-api SKILL.md
    const ttsStart = Date.now();
    let response: any = null;
    let lastTtsErr: any = null;

    try {
      const ttsPromise = activeAI.models.generateContent({
        model: 'gemini-3.8-flash-lite-tts',
        contents: [
          {
            role: 'user',
            parts: [{ text: cleanSpeech }],
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName },
            },
          },
        },
      });

      // 5000ms timeout allows high-quality neural voice to complete without premature timeouts
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('TTS synthesis timeout (5000ms)')), 5000),
      );

      const candidateResponse: any = await Promise.race([ttsPromise, timeoutPromise]);
      if (candidateResponse?.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data) {
        response = candidateResponse;
        console.log(`[TTS Perf] Audio synthesized with gemini-3.8-flash-lite-tts in ${Date.now() - ttsStart}ms`);
      }
    } catch (err: any) {
      lastTtsErr = err;
      console.warn(`[TTS Fallback] gemini-3.8-flash-lite-tts failed after ${Date.now() - ttsStart}ms:`, err?.message?.slice(0, 80));
    }

    if (!response) {
      const errString = (
        String(lastTtsErr?.message || '') +
        ' ' +
        String(lastTtsErr?.status || '') +
        ' ' +
        String(lastTtsErr?.code || '') +
        ' ' +
        String(lastTtsErr || '')
      ).toLowerCase();

      const isQuotaError =
        lastTtsErr?.status === 429 ||
        lastTtsErr?.code === 429 ||
        errString.includes('429') ||
        errString.includes('resource_exhausted') ||
        errString.includes('quota') ||
        errString.includes('rate-limit');

      if (isQuotaError) {
        ttsQuotaExhaustedUntil = Date.now() + 15000;
        res.json({
          fallback: true,
          rateLimited: true,
          retryAfterSeconds: 15,
          message: 'Gemini TTS quota reached. Seamless browser speech synthesis active.',
          voiceId,
        });
        return;
      }

      res.json({ fallback: true, error: lastTtsErr?.message || 'TTS synthesis unavailable', voiceId });
      return;
    }

    const part = response?.candidates?.[0]?.content?.parts?.[0];
    const rawBase64 = part?.inlineData?.data;
    const rawMime = part?.inlineData?.mimeType || 'audio/wav';

    if (!rawBase64) {
      res.json({ error: 'No audio data returned from speech engine', fallback: true, voiceId });
      return;
    }

    // Default Unary for gemini-3.8-flash-lite-tts is a complete WAV file.
    // Ensure standard WAV header if raw PCM L16 returned
    let finalBase64 = rawBase64;
    let finalMime = 'audio/wav';

    try {
      const isL16 = rawMime.toLowerCase().includes('l16') || rawMime.toLowerCase().includes('pcm');
      if (isL16) {
        const rawPcm = Buffer.from(rawBase64, 'base64');
        let sampleRate = 24000;
        const rateMatch = rawMime.match(/rate=(\d+)/i);
        if (rateMatch && rateMatch[1]) {
          sampleRate = parseInt(rateMatch[1], 10);
        }
        const wavBuffer = pcmToWav(rawPcm, sampleRate);
        finalBase64 = wavBuffer.toString('base64');
        finalMime = 'audio/wav';
      }
    } catch (_) {}

    if (ttsCache.size >= MAX_TTS_CACHE_ITEMS) {
      const oldestKey = ttsCache.keys().next().value;
      if (oldestKey) ttsCache.delete(oldestKey);
    }

    ttsCache.set(cacheKey, {
      audio: finalBase64,
      mimeType: finalMime,
      voiceId,
      voiceName,
    });

    res.json({
      audio: finalBase64,
      mimeType: finalMime,
      voiceId,
      voiceName,
    });
  } catch (error: any) {
    res.json({ error: error?.message || 'TTS generation failed', fallback: true });
  }
});

// Serve Vite dev server or static build
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`Alya Companion server running on http://0.0.0.0:${PORT}`);
    });
  } else {
    const http = await import('http');
    const server = http.createServer(app);
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    server.listen(PORT, '0.0.0.0', () => {
      console.log(`Alya Companion server running on http://0.0.0.0:${PORT}`);
    });
  }
}

startServer();
