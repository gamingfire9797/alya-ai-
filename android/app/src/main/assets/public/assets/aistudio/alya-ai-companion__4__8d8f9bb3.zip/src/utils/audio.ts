import { VoiceStyle } from '../types';
import { LanguageEngine } from './language';

let audioContext: AudioContext | null = null;

export function getAudioContext(): AudioContext | null {
  try {
    if (!audioContext && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        audioContext = new AudioCtx();
      }
    }
    if (audioContext && audioContext.state === 'suspended') {
      audioContext.resume().catch(() => {});
    }
    return audioContext;
  } catch (_) {
    return null;
  }
}

// Development latency tracker for performance investigation
export interface VoiceLatencyMetrics {
  sttFinalized: number;
  aiRequestStart: number;
  aiFirstChunk: number;
  aiResponseComplete: number;
  ttsRequestStart: number;
  ttsResponseReceived: number;
  audioPlayStart: number;
  audioPlayEnd: number;
}

export const VoiceLatencyTracker = {
  activeSessionId: 0,
  metrics: {
    sttFinalized: 0,
    aiRequestStart: 0,
    aiFirstChunk: 0,
    aiResponseComplete: 0,
    ttsRequestStart: 0,
    ttsResponseReceived: 0,
    audioPlayStart: 0,
    audioPlayEnd: 0,
  } as VoiceLatencyMetrics,
  start(id = Date.now()) {
    this.activeSessionId = id;
    this.metrics = {
      sttFinalized: performance.now(),
      aiRequestStart: 0,
      aiFirstChunk: 0,
      aiResponseComplete: 0,
      ttsRequestStart: 0,
      ttsResponseReceived: 0,
      audioPlayStart: 0,
      audioPlayEnd: 0,
    };
  },
  record(stage: keyof VoiceLatencyMetrics) {
    this.metrics[stage] = performance.now();
    const m = this.metrics;

    if (stage === 'aiFirstChunk' && m.aiRequestStart) {
      const ttft = Math.round(m.aiFirstChunk - m.aiRequestStart);
      console.log(`[Latency] Time-to-First-Token (TTFT): ${ttft}ms`);
    } else if (stage === 'aiResponseComplete' && m.aiRequestStart) {
      const aiTotal = Math.round(m.aiResponseComplete - m.aiRequestStart);
      console.log(`[Latency] AI Generation Complete: ${aiTotal}ms`);
    } else if (stage === 'ttsResponseReceived' && m.ttsRequestStart) {
      const ttsGen = Math.round(m.ttsResponseReceived - m.ttsRequestStart);
      console.log(`[Latency] TTS Audio Synthesis: ${ttsGen}ms`);
    } else if (stage === 'audioPlayStart') {
      const ttft = m.aiFirstChunk && m.aiRequestStart ? Math.round(m.aiFirstChunk - m.aiRequestStart) : 0;
      const ttsGen = m.ttsResponseReceived && m.ttsRequestStart ? Math.round(m.ttsResponseReceived - m.ttsRequestStart) : 0;
      const totalToSpeech = m.sttFinalized ? Math.round(m.audioPlayStart - m.sttFinalized) : 0;
      console.log(`[Latency] Audio Playback Started | TTFT: ${ttft}ms | TTS: ${ttsGen}ms | Total Voice Pipeline: ${totalToSpeech}ms`);
    }
  },
  getSummary() {
    const m = this.metrics;
    return {
      aiGenerationMs: m.aiResponseComplete && m.aiRequestStart ? Math.round(m.aiResponseComplete - m.aiRequestStart) : 0,
      ttsSynthesisMs: m.ttsResponseReceived && m.ttsRequestStart ? Math.round(m.ttsResponseReceived - m.ttsRequestStart) : 0,
      timeToFirstAudioMs: m.audioPlayStart && m.sttFinalized ? Math.round(m.audioPlayStart - m.sttFinalized) : 0,
    };
  },
};

// Procedural sound effects for companion interactions
export function playChime(type: 'heart' | 'send' | 'receive' | 'click' | 'switch' | 'listen_start' | 'listen_stop') {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    const now = ctx.currentTime;

    if (type === 'heart') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.12); // A5
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
      osc.start(now);
      osc.stop(now + 0.35);
    } else if (type === 'send') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(659.25, now + 0.1);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.start(now);
      osc.stop(now + 0.2);
    } else if (type === 'receive') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(659.25, now);
      osc.frequency.setValueAtTime(880, now + 0.08);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      osc.start(now);
      osc.stop(now + 0.3);
    } else if (type === 'listen_start') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, now); // C5
      osc.frequency.exponentialRampToValueAtTime(783.99, now + 0.09); // G5
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.start(now);
      osc.stop(now + 0.2);
    } else if (type === 'listen_stop') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(659.25, now);
      osc.frequency.exponentialRampToValueAtTime(440, now + 0.08);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      osc.start(now);
      osc.stop(now + 0.18);
    } else if (type === 'switch') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, now);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      osc.start(now);
      osc.stop(now + 0.08);
    } else {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(400, now);
      gain.gain.setValueAtTime(0.05, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
      osc.start(now);
      osc.stop(now + 0.05);
    }
  } catch (_) {}
}

// Procedural Ambient sound generator (Rain, Lo-Fi Hum, Cafe, Nature)
class AmbientSoundEngine {
  private noiseNode: AudioNode | null = null;
  private isPlaying = false;

  start(type: 'rain' | 'lofi' | 'cafe' | 'nature', volume = 0.3) {
    this.stop();
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const bufferSize = ctx.sampleRate * 2;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        data[i] = (lastOut + 0.02 * white) / 1.02;
        lastOut = data[i];
        data[i] *= 3.5;
      }
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      noise.loop = true;
      const filter = ctx.createBiquadFilter();
      if (type === 'rain') {
        filter.type = 'lowpass';
        filter.frequency.value = 1200;
      } else if (type === 'lofi') {
        filter.type = 'bandpass';
        filter.frequency.value = 400;
        filter.Q.value = 2;
      } else {
        filter.type = 'lowpass';
        filter.frequency.value = 800;
      }
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(volume * 0.25, ctx.currentTime);
      noise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      noise.start();
      this.noiseNode = noise;
      this.isPlaying = true;
    } catch (_) {}
  }

  stop() {
    if (this.noiseNode) {
      try {
        (this.noiseNode as AudioBufferSourceNode).stop();
        this.noiseNode.disconnect();
      } catch (_) {}
      this.noiseNode = null;
    }
    this.isPlaying = false;
  }

  active() {
    return this.isPlaying;
  }
}

export const ambientEngine = new AmbientSoundEngine();

export interface TTSOptions {
  volume?: number;
  speed?: number;
  pitch?: number;
  languageMode?: 'english' | 'hinglish' | 'hindi' | 'other';
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (err?: any) => void;
}

/**
 * High-Performance Companion TTS Engine
 * Features:
 * - Chunk-aware fast streaming playback for rapid perceived response
 * - In-memory LRU audio caching
 * - Fast graceful device fallback to Web Speech
 * - Hinglish & Hindi native phonetic handling
 * - Zero artificial sleep/wait intervals
 */
export class CompanionTTS {
  private static synth: SpeechSynthesis | null = typeof window !== 'undefined' ? window.speechSynthesis : null;
  private static currentAudio: HTMLAudioElement | null = null;
  private static sharedAudio: HTMLAudioElement | null = null;
  private static abortController: AbortController | null = null;
  private static speakingCallback: ((isSpeaking: boolean) => void) | null = null;
  private static isCurrentlySpeaking = false;
  private static audioCache = new Map<string, { audio: string; mimeType: string }>();
  private static cooldownUntil = 0;
  private static speechSessionId = 0;
  private static prefetchQueue = new Map<string, Promise<{ audio: string; mimeType: string } | null>>();
  private static isMuted = false;

  private static getSharedAudio(): HTMLAudioElement {
    if (!this.sharedAudio && typeof window !== 'undefined') {
      this.sharedAudio = new Audio();
      this.sharedAudio.preload = 'auto';
    }
    return this.sharedAudio!;
  }

  static setSpeakingListener(cb: (isSpeaking: boolean) => void) {
    this.speakingCallback = cb;
  }

  static getSessionId(): number {
    return this.speechSessionId;
  }

  static setMuted(muted: boolean) {
    this.isMuted = muted;
    if (muted) {
      this.stop();
    }
  }

  static getMuted(): boolean {
    return this.isMuted;
  }

  /**
   * Stop any playing audio immediately
   */
  static stop(triggerCallback = true) {
    this.speechSessionId++;
    if (this.abortController) {
      try {
        this.abortController.abort();
      } catch (_) {}
      this.abortController = null;
    }
    if (this.currentAudio) {
      try {
        this.currentAudio.pause();
        this.currentAudio.currentTime = 0;
        this.currentAudio.src = '';
        this.currentAudio.load();
      } catch (_) {}
      this.currentAudio = null;
    }
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch (_) {}
    }
    this.isCurrentlySpeaking = false;
    if (triggerCallback && this.speakingCallback) {
      this.speakingCallback(false);
    }
  }

  /**
   * Unlock Web Audio & Speech synthesis on mobile/safari user gesture
   */
  static unlockAudio() {
    if (typeof window === 'undefined') return;
    try {
      getAudioContext();
      if (this.synth && this.synth.paused) {
        this.synth.resume();
      }
    } catch (_) {}
  }

  /**
   * Clean speech text and remove markdown/tags
   */
  static cleanSpeechText(text: string): string {
    return text
      .replace(/^\[[a-zA-Z_-]+\]\s*/i, '') // Remove [happy], [normal], etc.
      .replace(/\[.*?\]/g, '')             // Remove other tags
      .replace(/\([^\)]*\)/g, '')          // Remove parenthetical notes
      .replace(/[*_#`~>]/g, '')            // Remove markdown
      .replace(/https?:\/\/\S+/gi, '')     // Remove URLs
      .replace(/([.!?])\s*([A-Za-z])/g, '$1 $2')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Split a long response into natural sentences to allow early TTS execution.
   */
  static splitIntoSentences(text: string): string[] {
    const clean = this.cleanSpeechText(text);
    if (!clean) return [];

    // Match sentences ending with ., !, ?, or Hindi purna viram ।
    const matched = clean.match(/[^.!?।\n]+[.!?।\n]+|[^.!?।\n]+$/g);
    if (!matched || matched.length === 0) {
      return [clean];
    }
    return matched.map((s) => s.trim()).filter((s) => s.length > 0);
  }

  /**
   * Primary entry point for speaking AI response.
   * If response contains multiple sentences, it initiates sentence 1 immediately
   * while preloading subsequent sentences in parallel.
   */
  static async speak(
    text: string,
    voiceStyle: VoiceStyle,
    options?: TTSOptions | (() => void)
  ): Promise<void> {
    this.stop(false);
    const currentSessionId = this.speechSessionId;
    const resolvedOptions: TTSOptions = typeof options === 'function' ? { onEnd: options } : (options || {});
    const cleanSpeech = this.cleanSpeechText(text);

    if (!cleanSpeech) {
      this.isCurrentlySpeaking = false;
      if (this.speakingCallback) this.speakingCallback(false);
      resolvedOptions.onEnd?.();
      return;
    }

    if (this.isMuted) {
      this.isCurrentlySpeaking = false;
      if (this.speakingCallback) this.speakingCallback(false);
      resolvedOptions.onStart?.();
      setTimeout(() => {
        resolvedOptions.onEnd?.();
      }, 80);
      return;
    }

    // Detect language mode of the speech text if not already provided
    const languageMode = resolvedOptions.languageMode || LanguageEngine.detectLanguage(cleanSpeech).mode;
    const sentences = this.splitIntoSentences(cleanSpeech);

    VoiceLatencyTracker.record('ttsRequestStart');

    // If single sentence, speak directly
    if (sentences.length <= 1) {
      await this.speakSingleSentence(currentSessionId, cleanSpeech, voiceStyle, {
        ...resolvedOptions,
        languageMode,
      });
      return;
    }

    // For multi-sentence responses: early chunk playback
    // Play sentence 1 immediately, and prefetch sentence 2+
    let currentIndex = 0;

    const playNextSentence = async () => {
      if (this.speechSessionId !== currentSessionId) return;

      if (currentIndex >= sentences.length) {
        this.isCurrentlySpeaking = false;
        if (this.speakingCallback) this.speakingCallback(false);
        resolvedOptions.onEnd?.();
        return;
      }

      const currentSentence = sentences[currentIndex];
      currentIndex++;

      // Preload next sentence in background if exists
      if (currentIndex < sentences.length) {
        this.preloadSentenceAudio(sentences[currentIndex], voiceStyle, languageMode);
      }

      await this.speakSingleSentence(currentSessionId, currentSentence, voiceStyle, {
        ...resolvedOptions,
        languageMode,
        onStart: () => {
          if (currentIndex === 1) {
            resolvedOptions.onStart?.();
          }
        },
        onEnd: () => {
          playNextSentence();
        },
        onError: () => {
          playNextSentence();
        },
      });
    };

    playNextSentence();
  }

  /**
   * Preload audio for a sentence to achieve zero gap between sentences
   */
  public static preloadSentenceAudio(
    sentence: string,
    voiceStyle: VoiceStyle,
    languageMode: string
  ): void {
    const cacheKey = `${voiceStyle.id}::${languageMode}::${sentence}`;
    if (this.audioCache.has(cacheKey) || this.prefetchQueue.has(cacheKey)) return;

    const fetchPromise = (async () => {
      try {
        const userApiKey = localStorage.getItem('alya_gemini_api_key_v1') || undefined;
        const res = await fetch('/api/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: sentence,
            voiceId: voiceStyle.id,
            language: languageMode,
            apiKey: userApiKey,
          }),
        });
        if (!res.ok) return null;
        const data = await res.json();
        if (data.audio) {
          const item = { audio: data.audio, mimeType: data.mimeType || 'audio/wav' };
          this.audioCache.set(cacheKey, item);
          return item;
        }
      } catch (_) {}
      return null;
    })();

    this.prefetchQueue.set(cacheKey, fetchPromise);
  }

  /**
   * Speak a single sentence chunk
   */
  public static async speakSingleSentence(
    sessionId: number,
    sentence: string,
    voiceStyle: VoiceStyle,
    options: TTSOptions
  ): Promise<void> {
    if (this.speechSessionId !== sessionId) return;

    const volume = typeof options.volume === 'number' ? Math.max(0, Math.min(1, options.volume)) : 1;
    const speed = typeof options.speed === 'number' ? options.speed : voiceStyle.rate || 1.0;
    const languageMode = options.languageMode || 'english';
    const cacheKey = `${voiceStyle.id}::${languageMode}::${sentence}`;

    // 1. Check in-memory cache
    const cached = this.audioCache.get(cacheKey);
    if (cached) {
      VoiceLatencyTracker.record('ttsResponseReceived');
      await this.playAudioBuffer(sessionId, cached.audio, cached.mimeType, volume, speed, sentence, voiceStyle, options);
      return;
    }

    // 2. Check if already prefetching
    if (this.prefetchQueue.has(cacheKey)) {
      const prefetched = await this.prefetchQueue.get(cacheKey);
      this.prefetchQueue.delete(cacheKey);
      if (prefetched && this.speechSessionId === sessionId) {
        VoiceLatencyTracker.record('ttsResponseReceived');
        await this.playAudioBuffer(sessionId, prefetched.audio, prefetched.mimeType, volume, speed, sentence, voiceStyle, options);
        return;
      }
    }

    // 3. Quota cooldown check -> fast Web Speech fallback
    if (Date.now() < this.cooldownUntil) {
      this.fallbackWebSpeech(sessionId, sentence, voiceStyle, options);
      return;
    }

    const controller = new AbortController();
    this.abortController = controller;

    try {
      const userApiKey = localStorage.getItem('alya_gemini_api_key_v1') || undefined;
      const response = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: sentence,
          voiceId: voiceStyle.id,
          language: languageMode,
          apiKey: userApiKey,
        }),
        signal: controller.signal,
      });

      if (this.speechSessionId !== sessionId || controller.signal.aborted) return;

      if (!response.ok) {
        this.fallbackWebSpeech(sessionId, sentence, voiceStyle, options);
        return;
      }

      const data = await response.json();
      if (this.speechSessionId !== sessionId || controller.signal.aborted) return;

      VoiceLatencyTracker.record('ttsResponseReceived');

      if (data.rateLimited || data.fallback || !data.audio) {
        if (data.retryAfterSeconds) {
          this.cooldownUntil = Date.now() + data.retryAfterSeconds * 1000;
        } else if (data.rateLimited) {
          this.cooldownUntil = Date.now() + 30000;
        }
        this.fallbackWebSpeech(sessionId, sentence, voiceStyle, options);
        return;
      }

      // Add to LRU cache
      if (this.audioCache.size > 80) {
        const oldest = this.audioCache.keys().next().value;
        if (oldest) this.audioCache.delete(oldest);
      }
      this.audioCache.set(cacheKey, { audio: data.audio, mimeType: data.mimeType || 'audio/wav' });

      await this.playAudioBuffer(sessionId, data.audio, data.mimeType || 'audio/wav', volume, speed, sentence, voiceStyle, options);
    } catch (_) {
      if (this.speechSessionId !== sessionId || controller.signal.aborted) return;
      this.fallbackWebSpeech(sessionId, sentence, voiceStyle, options);
    }
  }

  /**
   * Play base64 audio buffer using reused audio element and safe URL lifecycle
   */
  private static async playAudioBuffer(
    sessionId: number,
    base64Audio: string,
    mimeType: string,
    volume: number,
    speed: number,
    sentence: string,
    voiceStyle: VoiceStyle,
    options: TTSOptions
  ): Promise<void> {
    if (this.speechSessionId !== sessionId) return;

    let objectUrl: string | null = null;
    const cleanup = () => {
      if (objectUrl) {
        try {
          URL.revokeObjectURL(objectUrl);
        } catch (_) {}
        objectUrl = null;
      }
    };

    try {
      this.unlockAudio();
      const binaryString = atob(base64Audio);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const safeMime = mimeType || 'audio/wav';
      const blob = new Blob([bytes.buffer], { type: safeMime });
      objectUrl = URL.createObjectURL(blob);

      const audio = this.getSharedAudio();
      this.currentAudio = audio;
      audio.volume = Math.max(0, Math.min(1, volume));
      audio.playbackRate = Math.max(0.5, Math.min(2.0, speed));
      audio.src = objectUrl;

      audio.onplay = () => {
        if (this.speechSessionId !== sessionId) {
          try { audio.pause(); } catch (_) {}
          cleanup();
          return;
        }
        VoiceLatencyTracker.record('audioPlayStart');
        this.isCurrentlySpeaking = true;
        if (this.speakingCallback) this.speakingCallback(true);
        options.onStart?.();
      };

      audio.onended = () => {
        cleanup();
        audio.onplay = null;
        audio.onended = null;
        audio.onerror = null;
        if (this.speechSessionId === sessionId) {
          VoiceLatencyTracker.record('audioPlayEnd');
          this.currentAudio = null;
          options.onEnd?.();
        }
      };

      audio.onerror = () => {
        cleanup();
        audio.onplay = null;
        audio.onended = null;
        audio.onerror = null;
        this.fallbackWebSpeech(sessionId, sentence, voiceStyle, options);
      };

      await audio.play();
    } catch (_) {
      cleanup();
      this.fallbackWebSpeech(sessionId, sentence, voiceStyle, options);
    }
  }

  /**
   * Create an incremental streaming speaker that triggers early sentence TTS
   * as response tokens arrive, drastically reducing perceived latency.
   */
  static createStreamSpeaker(voiceStyle: VoiceStyle, options: TTSOptions): StreamSpeaker {
    this.stop(false);
    return new StreamSpeaker(this.speechSessionId, voiceStyle, options);
  }

  /**
   * Browser Web Speech Synthesis fallback with native Hindi/Hinglish voice selection
   */
  private static fallbackWebSpeech(
    sessionId: number,
    cleanSpeech: string,
    voiceStyle: VoiceStyle,
    options: TTSOptions
  ) {
    if (this.speechSessionId !== sessionId) return;
    if (!this.synth) {
      this.isCurrentlySpeaking = false;
      if (this.speakingCallback) this.speakingCallback(false);
      options.onEnd?.();
      return;
    }

    try {
      this.synth.cancel();
      const utterance = new SpeechSynthesisUtterance(cleanSpeech);
      utterance.volume = typeof options.volume === 'number' ? options.volume : 1;
      utterance.rate = typeof options.speed === 'number' ? options.speed : 1;

      const isHindiOrHinglish = options.languageMode === 'hindi' || options.languageMode === 'hinglish';
      const voices = this.synth.getVoices();

      if (voices.length > 0) {
        if (isHindiOrHinglish) {
          // Find Indian English voice (best for Hinglish) or Hindi voice
          const indianVoice = voices.find(
            (v) =>
              (v.lang === 'hi-IN' || v.lang === 'en-IN' || v.lang.startsWith('hi') || v.name.includes('India')) &&
              (voiceStyle.gender === 'female' ? !v.name.includes('Male') : true)
          ) || voices.find((v) => v.lang === 'en-IN');

          if (indianVoice) {
            utterance.voice = indianVoice;
            utterance.lang = indianVoice.lang;
          }
        } else {
          // Standard English voice selection
          if (voiceStyle.gender === 'female') {
            const femaleVoice = voices.find(
              (v) =>
                v.lang.startsWith('en') &&
                (v.name.includes('Samantha') ||
                  v.name.includes('Victoria') ||
                  v.name.includes('Google UK English Female') ||
                  v.name.includes('Female'))
            ) || voices.find((v) => v.lang.startsWith('en'));
            if (femaleVoice) utterance.voice = femaleVoice;
          } else {
            const isDeep = voiceStyle.id === 'jarvis_deep';
            const maleVoice = voices.find(
              (v) =>
                v.lang.startsWith('en') &&
                (isDeep
                  ? v.name.includes('Daniel') || v.name.includes('Oliver') || v.name.includes('Male')
                  : v.name.includes('Alex') || v.name.includes('Male'))
            ) || voices.find((v) => v.lang.startsWith('en'));
            if (maleVoice) utterance.voice = maleVoice;
          }
        }
      }

      utterance.onstart = () => {
        if (this.speechSessionId !== sessionId) {
          try { this.synth?.cancel(); } catch (_) {}
          return;
        }
        VoiceLatencyTracker.record('audioPlayStart');
        this.isCurrentlySpeaking = true;
        if (this.speakingCallback) this.speakingCallback(true);
        options.onStart?.();
      };

      utterance.onend = () => {
        if (this.speechSessionId === sessionId) {
          VoiceLatencyTracker.record('audioPlayEnd');
          this.isCurrentlySpeaking = false;
          if (this.speakingCallback) this.speakingCallback(false);
          options.onEnd?.();
        }
      };

      utterance.onerror = () => {
        if (this.speechSessionId === sessionId) {
          this.isCurrentlySpeaking = false;
          if (this.speakingCallback) this.speakingCallback(false);
          options.onError?.();
        }
      };

      this.synth.speak(utterance);
    } catch (_) {
      this.isCurrentlySpeaking = false;
      if (this.speakingCallback) this.speakingCallback(false);
      options.onEnd?.();
    }
  }

  static isSpeaking(): boolean {
    return this.isCurrentlySpeaking || (!!this.synth && this.synth.speaking);
  }
}

/**
 * StreamSpeaker - Incremental streaming speech processor
 * Consumes SSE streaming text chunks as they arrive from Gemini,
 * detects completed sentences, triggers TTS in parallel,
 * and maintains continuous audio playback without overlapping.
 */
export class StreamSpeaker {
  private sessionId: number;
  private voiceStyle: VoiceStyle;
  private options: TTSOptions;
  private buffer = '';
  private sentencesQueue: string[] = [];
  private isPlayingQueue = false;
  private isDoneStreaming = false;

  constructor(sessionId: number, voiceStyle: VoiceStyle, options: TTSOptions) {
    this.sessionId = sessionId;
    this.voiceStyle = voiceStyle;
    this.options = options;
  }

  feedChunk(chunk: string) {
    if (!chunk) return;
    this.buffer += chunk;

    // Detect complete sentences ending with ., !, ?, or Hindi । followed by space or newline
    const match = this.buffer.match(/^(.*?[.!?।\n]+)([\s\S]*)$/);
    if (match) {
      const sentence = match[1].trim();
      this.buffer = match[2];
      if (sentence.length >= 6) {
        this.enqueue(sentence);
      }
    }
  }

  finish() {
    this.isDoneStreaming = true;
    const remaining = this.buffer.trim();
    if (remaining.length > 0) {
      this.buffer = '';
      this.enqueue(remaining);
    } else if (!this.isPlayingQueue && this.sentencesQueue.length === 0) {
      this.options.onEnd?.();
    }
  }

  private enqueue(sentence: string) {
    const clean = CompanionTTS.cleanSpeechText(sentence);
    if (!clean) return;
    this.sentencesQueue.push(clean);

    // Immediately prefetch audio for this sentence chunk
    CompanionTTS.preloadSentenceAudio(clean, this.voiceStyle, this.options.languageMode || 'english');

    if (!this.isPlayingQueue) {
      this.playNext();
    }
  }

  private async playNext() {
    if (this.sentencesQueue.length === 0) {
      this.isPlayingQueue = false;
      if (this.isDoneStreaming) {
        this.options.onEnd?.();
      }
      return;
    }

    this.isPlayingQueue = true;
    const sentence = this.sentencesQueue.shift()!;

    if (CompanionTTS.getMuted()) {
      this.options.onStart?.();
      setTimeout(() => {
        this.playNext();
      }, 50);
      return;
    }

    // Preload next queued sentence in background
    if (this.sentencesQueue.length > 0) {
      CompanionTTS.preloadSentenceAudio(this.sentencesQueue[0], this.voiceStyle, this.options.languageMode || 'english');
    }

    await CompanionTTS.speakSingleSentence(this.sessionId, sentence, this.voiceStyle, {
      ...this.options,
      onStart: () => {
        this.options.onStart?.();
      },
      onEnd: () => {
        this.playNext();
      },
      onError: () => {
        this.playNext();
      },
    });
  }
}

