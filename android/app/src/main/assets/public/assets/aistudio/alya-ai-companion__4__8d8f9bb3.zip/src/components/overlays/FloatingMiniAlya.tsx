import React, { useState, useRef, useEffect } from 'react';
import { X, Maximize2 } from 'lucide-react';
import { LiveAudioWave } from '../character/LiveAudioWave';

interface FloatingMiniAlyaProps {
  visible: boolean;
  isSpeaking: boolean;
  isListening: boolean;
  onOpenApp: () => void;
  onClose: () => void;
}

export const FloatingMiniAlya: React.FC<FloatingMiniAlyaProps> = ({
  visible,
  isSpeaking,
  isListening,
  onOpenApp,
  onClose,
}) => {
  const [position, setPosition] = useState({ x: 20, y: 120 });
  const [isDragging, setIsDragging] = useState(false);
  const dragRef = useRef<{ startX: number; startY: number; initX: number; initY: number } | null>(null);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initX: position.x,
      initY: position.y,
    };
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!dragRef.current) return;
    const dx = e.clientX - dragRef.current.startX;
    const dy = e.clientY - dragRef.current.startY;
    setPosition({
      x: Math.max(10, Math.min(window.innerWidth - 260, dragRef.current.initX + dx)),
      y: Math.max(50, Math.min(window.innerHeight - 80, dragRef.current.initY + dy)),
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    dragRef.current = null;
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length > 0) {
      const touch = e.touches[0];
      dragRef.current = {
        startX: touch.clientX,
        startY: touch.clientY,
        initX: position.x,
        initY: position.y,
      };
      setIsDragging(true);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!dragRef.current || e.touches.length === 0) return;
    const touch = e.touches[0];
    const dx = touch.clientX - dragRef.current.startX;
    const dy = touch.clientY - dragRef.current.startY;
    setPosition({
      x: Math.max(10, Math.min(window.innerWidth - 260, dragRef.current.initX + dx)),
      y: Math.max(50, Math.min(window.innerHeight - 80, dragRef.current.initY + dy)),
    });
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
    dragRef.current = null;
  };

  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    } else {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  if (!visible) return null;

  return (
    <div
      style={{ left: `${position.x}px`, top: `${position.y}px` }}
      onMouseDown={handleMouseDown}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      className="fixed z-50 select-none cursor-grab active:cursor-grabbing animate-fadeIn"
    >
      <div className="glass-panel px-3.5 py-2 rounded-full border border-pink-500/40 shadow-[0_8px_30px_rgba(244,114,182,0.35)] flex items-center gap-3 bg-[#160f22]/90 backdrop-blur-xl">
        <div
          onClick={(e) => {
            e.stopPropagation();
            onOpenApp();
          }}
          className="relative w-8 h-8 rounded-full p-[1.5px] bg-gradient-to-tr from-pink-500 to-purple-500 cursor-pointer hover:scale-105 transition-transform"
        >
          <div className="w-full h-full rounded-full bg-[#1b1427] flex items-center justify-center text-xs">
            🌸
          </div>
          <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border border-black animate-pulse" />
        </div>

        <div
          onClick={(e) => {
            e.stopPropagation();
            onOpenApp();
          }}
          className="cursor-pointer min-w-[70px]"
        >
          <div className="text-[11px] font-bold text-white font-comfortaa leading-none">
            Alya
          </div>
          <div className="text-[9px] text-pink-300 font-medium">
            {isSpeaking ? 'Speaking...' : isListening ? 'Listening...' : 'Ready'}
          </div>
        </div>

        <LiveAudioWave
          active={isSpeaking || isListening}
          type="mini-wave"
          color={isSpeaking ? 'purple' : 'pink'}
        />

        <div className="flex items-center gap-1 pl-1 border-l border-white/10">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onOpenApp();
            }}
            className="w-6 h-6 rounded-full flex items-center justify-center text-slate-300 hover:text-white hover:bg-white/10"
            title="Expand app"
          >
            <Maximize2 size={12} />
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            className="w-6 h-6 rounded-full flex items-center justify-center text-slate-400 hover:text-rose-400 hover:bg-white/10"
            title="Close overlay"
          >
            <X size={12} />
          </button>
        </div>
      </div>
    </div>
  );
};
