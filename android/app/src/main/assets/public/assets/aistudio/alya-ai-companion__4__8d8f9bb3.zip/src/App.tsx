import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  CompanionCharacter,
  ScreenType,
  ExpressionType,
  ChatMessage,
  MemoryItem,
  BackgroundItem,
  VoiceStyle,
  AppSettings,
  UserProfile,
  RecognitionState,
  CoreCustomization,
  AutoFeaturesSettings,
} from './types';
import { BACKGROUNDS, VOICE_STYLES, INITIAL_SETTINGS, DEFAULT_AUTO_FEATURES } from './data/initialData';
import { Storage } from './utils/storage';
import { CompanionTTS, playChime, ambientEngine, VoiceLatencyTracker } from './utils/audio';
import { TimeEngine } from './utils/time';
import { LanguageEngine } from './utils/language';
import { PermissionManager } from './utils/permissions';

// Components
import { AnimatedCompanionBackground } from './components/character/AnimatedCompanionBackground';
import { TopBar } from './components/navigation/TopBar';
import { MenuDrawer } from './components/navigation/MenuDrawer';
import { FloatingMiniAlya } from './components/overlays/FloatingMiniAlya';
import { DynamicIsland } from './components/overlays/DynamicIsland';
import { AutoFeaturesModal } from './components/overlays/AutoFeaturesModal';
import { LocationPermissionModal } from './components/overlays/LocationPermissionModal';

// Screens
import { HomeScreen } from './components/screens/HomeScreen';
import { ChatScreen } from './components/screens/ChatScreen';
import { VoiceScreen } from './components/screens/VoiceScreen';
import { MemoryScreen } from './components/screens/MemoryScreen';
import { BackgroundsScreen } from './components/screens/BackgroundsScreen';
import { PhoneControlScreen } from './components/screens/PhoneControlScreen';
import { ScreenToolsScreen } from './components/screens/ScreenToolsScreen';
import { SettingsScreen } from './components/screens/SettingsScreen';
import { OnboardingGuideScreen } from './components/screens/OnboardingGuideScreen';
import { SplashScreen } from './components/screens/SplashScreen';
import { NewOnboardingScreen } from './components/screens/NewOnboardingScreen';
import { ApiKeySetupScreen } from './components/screens/ApiKeySetupScreen';
import { AdminLoginScreen } from './components/admin/AdminLoginScreen';
import { AdminControlPanel } from './components/admin/AdminControlPanel';
import { EditProfileModal } from './components/profile/EditProfileModal';
import { CoreCustomizationStudio } from './components/studio/CoreCustomizationStudio';
import { SlidesScreen } from './components/screens/SlidesScreen';
import { WorkScreen } from './components/screens/WorkScreen';

export default function App() {
  // State Initialization
  const [settings, setSettings] = useState<AppSettings>(() => Storage.loadSettings());
  const [character, setCharacter] = useState<CompanionCharacter>(() => settings.selectedCompanion || 'alya');
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('home');
  const [isPhoneFrame, setIsPhoneFrame] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showAutoFeaturesModal, setShowAutoFeaturesModal] = useState(false);
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [hasServerKey, setHasServerKey] = useState(true);
  const [userApiKey, setUserApiKey] = useState<string>(() => Storage.loadApiKey());
  const [showStudioModal, setShowStudioModal] = useState(false);

  // Auto Features State (Auto Mic, Auto Listen, Auto Reply, Auto TTS, Auto Retry, Smart Interruption, Conversation Continuation)
  const [autoFeatures, setAutoFeatures] = useState<AutoFeaturesSettings>(() => {
    return settings.autoFeatures || Storage.loadAutoFeatures() || DEFAULT_AUTO_FEATURES;
  });

  const [coreCustomization, setCoreCustomization] = useState<CoreCustomization>(() => {
    return settings.coreCustomization || INITIAL_SETTINGS.coreCustomization!;
  });

  // User Profile & Sessions
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    const saved = Storage.loadUserProfile();
    if (saved) return saved;
    const defaultProfile: UserProfile = {
      id: 'usr_default_gamingfire',
      displayName: settings.userName || 'Gamingfire',
      username: 'gamingfire',
      avatarUrl: 'alya_pink',
      bannerUrl: 'cyber_neon',
      companionPreference: character,
      hasCompletedProfile: true,
      hasCompletedOnboarding: true,
      hasCompletedKeySetup: false,
      createdAt: new Date().toISOString(),
      communicationStyle: {
        dominantLanguage: 'english',
        hinglishAffinity: 0.4,
        hindiAffinity: 0.1,
        englishAffinity: 0.5,
        formality: 'casual',
        preferredPacing: 'natural',
        lastUpdated: new Date().toISOString(),
      },
    };
    Storage.saveUserProfile(defaultProfile);
    return defaultProfile;
  });

  const [sessionToken, setSessionToken] = useState<string | null>(() => {
    return Storage.loadAuthSession()?.token || null;
  });

  const [showEditProfileModal, setShowEditProfileModal] = useState(false);

  // Admin session
  const [adminToken, setAdminToken] = useState<string | null>(() => {
    return localStorage.getItem('alya_admin_token_v1') || null;
  });
  const [adminEmail, setAdminEmail] = useState<string>(() => {
    return localStorage.getItem('alya_admin_email_v1') || 'admin@alya.ai';
  });

  // Companion Expression & Audio States
  const [expression, setExpression] = useState<ExpressionType>('normal');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const [recognitionState, setRecognitionState] = useState<RecognitionState>('idle');
  const [micErrorMessage, setMicErrorMessage] = useState<string | null>(null);
  const [lastVoiceTranscript, setLastVoiceTranscript] = useState('');
  const [alyaVoiceReply, setAlyaVoiceReply] = useState('');

  // Floating Overlays
  const [floatingMiniVisible, setFloatingMiniVisible] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  const handleToggleMute = useCallback(() => {
    setIsMuted((prev) => {
      const next = !prev;
      CompanionTTS.setMuted(next);
      return next;
    });
  }, []);

  // Data
  const [messages, setMessages] = useState<ChatMessage[]>(() =>
    Storage.loadMessages(character, currentUser?.displayName || settings.userName || 'Gamingfire')
  );
  const [memories, setMemories] = useState<MemoryItem[]>(() => Storage.loadMemories());
  const [backgrounds, setBackgrounds] = useState<BackgroundItem[]>(() => {
    const custom = Storage.loadCustomBackgrounds();
    return [...BACKGROUNDS, ...custom];
  });
  const [activeBackground, setActiveBackground] = useState<BackgroundItem>(() => Storage.loadBackground());

  // Speech Recognition & Control Refs
  const [isAutoVoiceActive, setIsAutoVoiceActive] = useState(false);
  const isAutoVoiceActiveRef = useRef(false);
  const isHoldToTalkRef = useRef(false);
  const silenceTimerRef = useRef<any>(null);
  const activeTranscriptRef = useRef<string>('');
  const recognitionRef = useRef<any>(null);
  const isListeningRef = useRef(false);
  const isSpeakingRef = useRef(false);
  const autoFeaturesRef = useRef(autoFeatures);
  const restartTimerRef = useRef<any>(null);
  const isProcessingVoiceRef = useRef(false);
  const expressionRef = useRef(expression);

  // Keep refs in sync with state
  useEffect(() => {
    isAutoVoiceActiveRef.current = isAutoVoiceActive;
  }, [isAutoVoiceActive]);

  useEffect(() => {
    expressionRef.current = expression;
  }, [expression]);

  useEffect(() => {
    isListeningRef.current = isListening;
  }, [isListening]);

  useEffect(() => {
    isSpeakingRef.current = isSpeaking;
  }, [isSpeaking]);

  useEffect(() => {
    autoFeaturesRef.current = autoFeatures;
  }, [autoFeatures]);

  // Calibrate time engine and check backend status on load
  useEffect(() => {
    TimeEngine.calibrateWithServer();

    fetch('/api/status')
      .then((res) => res.json())
      .then((data) => {
        if (typeof data.hasGeminiKey === 'boolean') {
          setHasServerKey(data.hasGeminiKey);
        }
      })
      .catch(() => {});
  }, []);

  // Sync TTS speaking listener
  useEffect(() => {
    CompanionTTS.setSpeakingListener((speaking) => {
      setIsSpeaking(speaking);
      isSpeakingRef.current = speaking;
      if (!speaking && (expressionRef.current === ('talking' as any) || expressionRef.current === 'thinking')) {
        setExpression('normal');
      }
    });
    return () => {
      CompanionTTS.stop();
    };
  }, []);

  // Handle ambient sound on background change or settings
  useEffect(() => {
    if (settings.ambientMusic) {
      const sound = activeBackground.ambientSound || 'rain';
      if (sound !== 'none') {
        ambientEngine.start(sound as any, settings.ambientVolume || 0.3);
      } else {
        ambientEngine.stop();
      }
    } else {
      ambientEngine.stop();
    }
  }, [settings.ambientMusic, settings.ambientVolume, activeBackground]);

  // Get active voice style based on companion & settings
  const getActiveVoiceStyle = useCallback((): VoiceStyle => {
    if (character === 'jarvis') {
      const styleId = settings.jarvisVoice || 'jarvis_deep';
      return VOICE_STYLES.find((v) => v.id === styleId) || VOICE_STYLES[0];
    }
    const styleId = settings.alyaVoiceId || settings.selectedVoiceId || 'alya_natural';
    return VOICE_STYLES.find((v) => v.id === styleId) || VOICE_STYLES[4];
  }, [character, settings]);

  // Companion Switching
  const handleSwitchCompanion = (newChar: CompanionCharacter) => {
    if (newChar === character) return;
    if (settings.soundEffects) playChime('switch');
    CompanionTTS.stop();
    stopListening();
    setCharacter(newChar);
    setSettings((prev) => {
      const updated = { ...prev, selectedCompanion: newChar };
      Storage.saveSettings(updated);
      return updated;
    });
    const newMsgs = Storage.loadMessages(newChar, currentUser?.displayName || settings.userName);
    setMessages(newMsgs);
    setExpression('normal');
  };

  // Expression auto reset after timer
  useEffect(() => {
    if (expression !== 'normal' && expression !== 'thinking') {
      const timer = setTimeout(() => {
        setExpression('normal');
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [expression]);

  // Stop listening helper
  const stopListening = useCallback(() => {
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }
    if (restartTimerRef.current) {
      clearTimeout(restartTimerRef.current);
      restartTimerRef.current = null;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch (_) {}
      recognitionRef.current = null;
    }
    setIsListening(false);
    isListeningRef.current = false;
    setRecognitionState('idle');
  }, []);

  // START LISTENING HELPER with dynamic language recognition and 3-second natural silence detection
  const startListening = useCallback((isHoldMode = false) => {
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }
    if (restartTimerRef.current) {
      clearTimeout(restartTimerRef.current);
      restartTimerRef.current = null;
    }

    // Smart interruption: If AI is currently speaking, stop immediately
    if (isSpeakingRef.current) {
      CompanionTTS.stop();
      setIsSpeaking(false);
      isSpeakingRef.current = false;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setRecognitionState('error');
      setMicErrorMessage('Voice recognition is not supported in this browser. Please use Chrome or Edge.');
      return;
    }

    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch (_) {}
      recognitionRef.current = null;
    }

    try {
      CompanionTTS.unlockAudio();
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;

      // Adapt STT language dynamically for Hinglish / Indian English / Hindi / US English
      const userLangPref = settings.preferredLanguage || 'auto';
      const dominantStyle = currentUser?.communicationStyle?.dominantLanguage || 'english';
      const userTz = TimeEngine.getTimezone();
      const isIndiaRegion = userTz.includes('Kolkata') || userTz.includes('Calcutta') || userTz.includes('Asia/Colombo');

      if (userLangPref === 'hindi' || dominantStyle === 'hindi') {
        recognition.lang = 'hi-IN';
      } else if (userLangPref === 'hinglish' || dominantStyle === 'hinglish' || isIndiaRegion) {
        // 'en-IN' recognizes Indian English and Hindi loanwords far better in Chrome/Edge
        recognition.lang = 'en-IN';
      } else {
        recognition.lang = 'en-US';
      }

      recognition.onstart = () => {
        setIsListening(true);
        isListeningRef.current = true;
        setRecognitionState('listening');
        setMicErrorMessage(null);
        setLastVoiceTranscript('');
        activeTranscriptRef.current = '';
        isProcessingVoiceRef.current = false;
        if (settings.soundEffects) playChime('listen_start');
      };

      recognition.onsoundstart = () => {
        if (silenceTimerRef.current) {
          clearTimeout(silenceTimerRef.current);
          silenceTimerRef.current = null;
        }
      };

      recognition.onspeechstart = () => {
        if (silenceTimerRef.current) {
          clearTimeout(silenceTimerRef.current);
          silenceTimerRef.current = null;
        }
      };

      recognition.onresult = (event: any) => {
        // Smart interruption if companion is speaking
        if (isSpeakingRef.current) {
          CompanionTTS.stop();
          setIsSpeaking(false);
          isSpeakingRef.current = false;
        }

        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const item = event.results[i];
          if (item.isFinal) {
            finalTranscript += item[0].transcript;
          } else {
            interimTranscript += item[0].transcript;
          }
        }

        const currentText = (finalTranscript || interimTranscript).trim();
        if (currentText) {
          setLastVoiceTranscript(currentText);
          activeTranscriptRef.current = currentText;

          if (silenceTimerRef.current) {
            clearTimeout(silenceTimerRef.current);
            silenceTimerRef.current = null;
          }

          // Preserve 3-second natural silence detection for speech pauses
          if (!isHoldToTalkRef.current && !isProcessingVoiceRef.current) {
            silenceTimerRef.current = setTimeout(() => {
              const toSend = activeTranscriptRef.current.trim();
              if (toSend && !isProcessingVoiceRef.current) {
                isProcessingVoiceRef.current = true;
                stopListening();
                handleSendMessage(toSend);
              }
            }, 3000);
          }
        }
      };

      recognition.onerror = (event: any) => {
        if (silenceTimerRef.current) {
          clearTimeout(silenceTimerRef.current);
          silenceTimerRef.current = null;
        }
        if (event.error === 'not-allowed') {
          setIsListening(false);
          isListeningRef.current = false;
          setIsAutoVoiceActive(false);
          isAutoVoiceActiveRef.current = false;
          setRecognitionState('error');
          setMicErrorMessage('Microphone access was denied. Please allow microphone permissions.');
        } else if (event.error === 'no-speech') {
          if (isAutoVoiceActiveRef.current && isListeningRef.current && !isSpeakingRef.current && !isProcessingVoiceRef.current) {
            restartTimerRef.current = setTimeout(() => {
              if (isAutoVoiceActiveRef.current && isListeningRef.current && !isSpeakingRef.current && !isProcessingVoiceRef.current) {
                startListening();
              }
            }, 300);
          }
        } else if (event.error === 'aborted') {
          // Normal when stopped programmatically
        } else {
          setMicErrorMessage(`Mic: ${event.error}`);
        }
      };

      recognition.onend = () => {
        if (silenceTimerRef.current) {
          clearTimeout(silenceTimerRef.current);
          silenceTimerRef.current = null;
        }

        if (activeTranscriptRef.current.trim() && !isProcessingVoiceRef.current) {
          isProcessingVoiceRef.current = true;
          const toSend = activeTranscriptRef.current.trim();
          setIsListening(false);
          isListeningRef.current = false;
          setRecognitionState('idle');
          handleSendMessage(toSend);
          return;
        }

        if (
          isAutoVoiceActiveRef.current &&
          isListeningRef.current &&
          !isSpeakingRef.current &&
          !isProcessingVoiceRef.current
        ) {
          restartTimerRef.current = setTimeout(() => {
            if (isAutoVoiceActiveRef.current && !isSpeakingRef.current && !isProcessingVoiceRef.current) {
              startListening();
            }
          }, 300);
        } else if (!isProcessingVoiceRef.current) {
          setIsListening(false);
          isListeningRef.current = false;
          setRecognitionState('idle');
        }
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (e: any) {
      setIsListening(false);
      isListeningRef.current = false;
      setRecognitionState('error');
      setMicErrorMessage(e?.message || 'Could not start voice recognition.');
    }
  }, [settings.soundEffects, settings.preferredLanguage, currentUser, stopListening]);

  // TOGGLE VOICE: Center Microphone = Auto Voice Mode (Hands-free Continuous Loop)
  const handleToggleVoice = useCallback(() => {
    CompanionTTS.unlockAudio();

    // 1. If currently speaking: Smart Interruption
    if (isSpeakingRef.current) {
      CompanionTTS.stop();
      setIsSpeaking(false);
      isSpeakingRef.current = false;
      setIsAutoVoiceActive(true);
      isAutoVoiceActiveRef.current = true;
      startListening();
      return;
    }

    // 2. If Auto Voice is active or listening: Turn it OFF
    if (isAutoVoiceActiveRef.current || isListeningRef.current) {
      setIsAutoVoiceActive(false);
      isAutoVoiceActiveRef.current = false;
      if (settings.soundEffects) playChime('listen_stop');
      stopListening();
      return;
    }

    // 3. Otherwise: Turn ON Auto Voice mode
    setIsAutoVoiceActive(true);
    isAutoVoiceActiveRef.current = true;
    startListening();
  }, [settings.soundEffects, startListening, stopListening]);

  // HOLD-TO-TALK CONTROLS (Separate from Auto Voice Mode)
  const handleHoldToTalkStart = useCallback(() => {
    CompanionTTS.unlockAudio();
    if (isSpeakingRef.current) {
      CompanionTTS.stop();
      setIsSpeaking(false);
      isSpeakingRef.current = false;
    }
    isHoldToTalkRef.current = true;
    activeTranscriptRef.current = '';
    setLastVoiceTranscript('');
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }
    startListening(true);
  }, [startListening]);

  const handleHoldToTalkEnd = useCallback(() => {
    if (!isHoldToTalkRef.current && !isListeningRef.current) return;
    isHoldToTalkRef.current = false;
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }
    const toSend = activeTranscriptRef.current.trim();
    stopListening();
    if (toSend && !isProcessingVoiceRef.current) {
      isProcessingVoiceRef.current = true;
      handleSendMessage(toSend);
    }
  }, [stopListening]);

  // CANCEL VOICE HELPER
  const handleCancelVoice = useCallback(() => {
    setIsAutoVoiceActive(false);
    isAutoVoiceActiveRef.current = false;
    isHoldToTalkRef.current = false;
    activeTranscriptRef.current = '';
    setLastVoiceTranscript('');
    stopListening();
  }, [stopListening]);

  // SEND MESSAGE (With Dynamic Time Injection, Language Adaptation & Ultra-Low Latency Pipeline)
  const handleSendMessage = async (text: string, imageAttachment?: string, retryCount = 0) => {
    if (!text.trim() && !imageAttachment) return;
    CompanionTTS.unlockAudio();
    isProcessingVoiceRef.current = true;

    VoiceLatencyTracker.start();

    if (settings.soundEffects) playChime('send');

    // 1. Centralized dynamic live timestamp
    const liveTimestamp = TimeEngine.formatChatTimestamp();

    // 2. Language Detection & Style Adaptation before generating response
    const detection = LanguageEngine.detectLanguage(text);
    const updatedStyle = LanguageEngine.updateStyleProfile(currentUser?.communicationStyle, text);
    Storage.saveCommunicationStyle(updatedStyle);
    if (currentUser) {
      const updatedUser = { ...currentUser, communicationStyle: updatedStyle };
      setCurrentUser(updatedUser);
      Storage.saveUserProfile(updatedUser);
    }

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      text: text.trim(),
      timestamp: liveTimestamp,
      imageAttachment,
      language: detection.mode,
    };

    setMessages((prev) => {
      const next = [...prev, userMsg];
      Storage.saveMessages(character, next);
      return next;
    });

    // Show Thinking State
    setIsThinking(true);
    setExpression('thinking');
    setLastVoiceTranscript('');
    activeTranscriptRef.current = '';

    VoiceLatencyTracker.record('aiRequestStart');

    try {
      // 3. Lightweight relevant memory retrieval for low context overhead
      const memoryTexts = Storage.getLightweightRelevantMemories(text.trim(), memories);
      const timeContext = TimeEngine.getFullContext();

      // Determine language mode to instruct AI
      const effectiveLanguageMode =
        settings.preferredLanguage && settings.preferredLanguage !== 'auto'
          ? settings.preferredLanguage
          : detection.mode;

      const shouldSpeak = settings.autoSpeakResponse !== false;
      const voiceStyle = getActiveVoiceStyle();

      // Try fast streaming response first for sub-second perceived voice latency
      let streamSucceeded = false;
      try {
        const streamRes = await fetch('/api/chat/stream', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: text.trim(),
            history: messages.slice(-6).map((m) => ({
              role: m.role,
              text: m.text.length > 300 ? m.text.slice(0, 300) + '...' : m.text,
              isError: m.isError,
            })),
            character,
            userName: currentUser?.displayName || settings.userName || 'Friend',
            memories: memoryTexts,
            userApiKey: userApiKey || undefined,
            timeContext,
            languageMode: effectiveLanguageMode,
          }),
        });

        if (streamRes.ok && streamRes.body) {
          setIsThinking(false);
          setIsStreaming(true);
          VoiceLatencyTracker.record('aiFirstChunk');

          let streamSpeaker = shouldSpeak
            ? CompanionTTS.createStreamSpeaker(voiceStyle, {
                volume: settings.voiceVolume ?? 1.0,
                speed: settings.voiceSpeed ?? 1.0,
                pitch: settings.voicePitch ?? 1.0,
                languageMode: effectiveLanguageMode as any,
                onStart: () => {
                  setIsSpeaking(true);
                  isSpeakingRef.current = true;
                },
                onEnd: () => {
                  setIsSpeaking(false);
                  isSpeakingRef.current = false;
                  isProcessingVoiceRef.current = false;
                  if (isAutoVoiceActiveRef.current) {
                    setTimeout(() => {
                      if (isAutoVoiceActiveRef.current && !isSpeakingRef.current) {
                        startListening();
                      }
                    }, 300);
                  }
                },
                onError: () => {
                  setIsSpeaking(false);
                  isSpeakingRef.current = false;
                  isProcessingVoiceRef.current = false;
                  if (isAutoVoiceActiveRef.current) {
                    setTimeout(() => {
                      if (isAutoVoiceActiveRef.current && !isSpeakingRef.current) {
                        startListening();
                      }
                    }, 400);
                  }
                },
              })
            : null;

          const reader = streamRes.body.getReader();
          const decoder = new TextDecoder();
          let botText = '';
          let botEmotion: ExpressionType = 'normal';
          let streamBuffer = '';
          const botMsgId = `bot-${Date.now()}`;

          // Create placeholder message in state
          setMessages((prev) => [
            ...prev,
            {
              id: botMsgId,
              role: character,
              text: '',
              timestamp: TimeEngine.formatChatTimestamp(),
              emotion: 'normal',
            },
          ]);

          while (true) {
            const { value, done } = await reader.read();
            if (done) break;

            streamBuffer += decoder.decode(value, { stream: true });
            const lines = streamBuffer.split('\n');
            streamBuffer = lines.pop() || '';

            for (const line of lines) {
              if (!line.startsWith('data: ')) continue;
              try {
                const data = JSON.parse(line.slice(6));
                if (data.emotion) {
                  botEmotion = data.emotion;
                  setExpression(data.emotion);
                }
                if (data.chunk) {
                  botText += data.chunk;
                  setMessages((prev) =>
                    prev.map((m) =>
                      m.id === botMsgId ? { ...m, text: botText, emotion: botEmotion } : m
                    )
                  );
                  setAlyaVoiceReply(botText);
                  if (streamSpeaker) {
                    streamSpeaker.feedChunk(data.chunk);
                  }
                }
              } catch (_) {}
            }
          }

          setIsStreaming(false);
          VoiceLatencyTracker.record('aiResponseComplete');

          const finalReply = botText.trim() || (character === 'jarvis' ? 'Understood.' : 'I see!');
          setMessages((prev) => {
            const next = prev.map((m) =>
              m.id === botMsgId
                ? {
                    ...m,
                    text: finalReply,
                    emotion: botEmotion,
                    language: LanguageEngine.detectLanguage(finalReply).mode,
                  }
                : m
            );
            Storage.saveMessages(character, next);
            return next;
          });

          if (settings.soundEffects) playChime('receive');
          setAlyaVoiceReply(finalReply);

          if (streamSpeaker) {
            streamSpeaker.finish();
          } else {
            isProcessingVoiceRef.current = false;
            if (isAutoVoiceActiveRef.current) {
              setTimeout(() => {
                if (isAutoVoiceActiveRef.current && !isSpeakingRef.current) {
                  startListening();
                }
              }, 300);
            }
          }

          streamSucceeded = true;
          return;
        }
      } catch (streamErr) {
        console.warn('Streaming fallback active:', streamErr);
      }

      // Non-streaming fallback
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text.trim(),
          history: messages.slice(-6).map((m) => ({
            role: m.role,
            text: m.text.length > 300 ? m.text.slice(0, 300) + '...' : m.text,
            isError: m.isError,
          })),
          character,
          userName: currentUser?.displayName || settings.userName || 'Friend',
          memories: memoryTexts,
          userApiKey: userApiKey || undefined,
          requestId: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          timeContext,
          languageMode: effectiveLanguageMode,
        }),
      });

      const data = await res.json();
      setIsThinking(false);
      VoiceLatencyTracker.record('aiResponseComplete');

      // Handle server error only when no reply is available
      if ((!res.ok || data.error) && !data.reply) {
        if (autoFeatures.autoRetry && retryCount < 1) {
          setTimeout(() => {
            handleSendMessage(text, imageAttachment, retryCount + 1);
          }, 1200);
          return;
        }

        const errorText = data.error || 'Connection error. Please try again.';
        const errorMsg: ChatMessage = {
          id: `err-${Date.now()}`,
          role: character,
          text: errorText,
          timestamp: TimeEngine.formatChatTimestamp(),
          isError: true,
          emotion: 'concerned',
        };

        setMessages((prev) => {
          const next = [...prev, errorMsg];
          Storage.saveMessages(character, next);
          return next;
        });

        setExpression('concerned');
        isProcessingVoiceRef.current = false;

        if (isAutoVoiceActiveRef.current) {
          setTimeout(() => {
            if (isAutoVoiceActiveRef.current && !isSpeakingRef.current) {
              startListening();
            }
          }, 800);
        }
        return;
      }

      const botReply = data.reply || (character === 'jarvis' ? 'Understood.' : 'I see!');
      const botEmotion: ExpressionType = (data.emotion as ExpressionType) || 'normal';
      setExpression(botEmotion);

      const botLanguage = LanguageEngine.detectLanguage(botReply).mode;

      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        role: character,
        text: botReply,
        timestamp: TimeEngine.formatChatTimestamp(),
        emotion: botEmotion,
        isHighDemand: data.isHighDemand,
        language: botLanguage,
      };

      setMessages((prev) => {
        const next = [...prev, botMsg];
        Storage.saveMessages(character, next);
        return next;
      });

      if (settings.soundEffects) playChime('receive');
      setAlyaVoiceReply(botReply);

      // AUTO-SPEAK RESPONSE: Alya speaks through optimized low-latency TTS
      if (shouldSpeak) {
        const voiceStyle = getActiveVoiceStyle();

        CompanionTTS.speak(botReply, voiceStyle, {
          volume: settings.voiceVolume ?? 1.0,
          speed: settings.voiceSpeed ?? 1.0,
          pitch: settings.voicePitch ?? 1.0,
          languageMode: botLanguage,
          onStart: () => {
            setIsSpeaking(true);
            isSpeakingRef.current = true;
          },
          onEnd: () => {
            setIsSpeaking(false);
            isSpeakingRef.current = false;
            isProcessingVoiceRef.current = false;

            // When AI finishes speaking: resume Auto Voice listening after brief natural breath pause
            if (isAutoVoiceActiveRef.current) {
              setTimeout(() => {
                if (isAutoVoiceActiveRef.current && !isSpeakingRef.current) {
                  startListening();
                }
              }, 300);
            }
          },
          onError: () => {
            setIsSpeaking(false);
            isSpeakingRef.current = false;
            isProcessingVoiceRef.current = false;

            if (isAutoVoiceActiveRef.current) {
              setTimeout(() => {
                if (isAutoVoiceActiveRef.current && !isSpeakingRef.current) {
                  startListening();
                }
              }, 400);
            }
          },
        });
      } else {
        isProcessingVoiceRef.current = false;
        if (isAutoVoiceActiveRef.current) {
          setTimeout(() => {
            if (isAutoVoiceActiveRef.current && !isSpeakingRef.current) {
              startListening();
            }
          }, 400);
        }
      }
    } catch (err: any) {
      setIsThinking(false);
      isProcessingVoiceRef.current = false;

      if (autoFeatures.autoRetry && retryCount < 2) {
        setTimeout(() => {
          handleSendMessage(text, imageAttachment, retryCount + 1);
        }, 1200);
        return;
      }

      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: character,
        text: 'The AI connection had a momentary glitch. Automatic recovery active.',
        timestamp: TimeEngine.formatChatTimestamp(),
        isError: true,
        emotion: 'concerned',
      };

      setMessages((prev) => {
        const next = [...prev, errorMsg];
        Storage.saveMessages(character, next);
        return next;
      });

      if (isAutoVoiceActiveRef.current) {
        setTimeout(() => {
          if (isAutoVoiceActiveRef.current && !isSpeakingRef.current) {
            startListening();
          }
        }, 800);
      }
    }
  };

  // Speak single message manually
  const handleSpeakMessage = (text: string) => {
    CompanionTTS.unlockAudio();
    const voiceStyle = getActiveVoiceStyle();
    const detectedLang = LanguageEngine.detectLanguage(text).mode;

    CompanionTTS.speak(text, voiceStyle, {
      volume: settings.voiceVolume,
      speed: settings.voiceSpeed,
      pitch: settings.voicePitch,
      languageMode: detectedLang,
      onStart: () => {
        setIsSpeaking(true);
      },
      onEnd: () => {
        setIsSpeaking(false);
      },
    });
  };

  // Stop speaking
  const handleStopSpeaking = () => {
    CompanionTTS.stop();
    setIsSpeaking(false);
    isSpeakingRef.current = false;
  };

  // Update Settings
  const handleUpdateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...newSettings };
      Storage.saveSettings(updated);
      return updated;
    });
  };

  // Update Auto Features
  const handleUpdateAutoFeatures = (updated: Partial<AutoFeaturesSettings>) => {
    setAutoFeatures((prev) => {
      const merged = { ...prev, ...updated };
      autoFeaturesRef.current = merged;
      Storage.saveAutoFeatures(merged);
      handleUpdateSettings({ autoFeatures: merged });
      return merged;
    });
  };

  // Reset Settings
  const handleResetSettings = () => {
    setSettings(INITIAL_SETTINGS);
    setAutoFeatures(DEFAULT_AUTO_FEATURES);
    Storage.saveSettings(INITIAL_SETTINGS);
    Storage.saveAutoFeatures(DEFAULT_AUTO_FEATURES);
  };

  // Memory Handlers
  const handleAddMemory = (category: MemoryItem['category'], text: string) => {
    const clean = Storage.sanitizeMemoryText(text);
    if (!clean) return;

    const newMem: MemoryItem = {
      id: `mem-${Date.now()}`,
      category,
      text: clean,
      dateAdded: TimeEngine.formatHumanDate(),
      pinned: false,
    };
    const updated = [newMem, ...memories];
    setMemories(updated);
    Storage.saveMemories(updated);
  };

  const handleEditMemory = (id: string, text: string) => {
    const clean = Storage.sanitizeMemoryText(text);
    if (!clean) return;

    const updated = memories.map((m) => (m.id === id ? { ...m, text: clean } : m));
    setMemories(updated);
    Storage.saveMemories(updated);
  };

  const handleDeleteMemory = (id: string) => {
    const updated = memories.filter((m) => m.id !== id);
    setMemories(updated);
    Storage.saveMemories(updated);
  };

  const handleTogglePinMemory = (id: string) => {
    const updated = memories.map((m) => (m.id === id ? { ...m, pinned: !m.pinned } : m));
    setMemories(updated);
    Storage.saveMemories(updated);
  };

  // Background Handlers
  const handleApplyBackground = (bg: BackgroundItem) => {
    setActiveBackground(bg);
    Storage.saveBackground(bg);
  };

  const handleAddCustomBackground = (bg: BackgroundItem) => {
    const custom = Storage.loadCustomBackgrounds();
    const updatedCustom = [bg, ...custom];
    Storage.saveCustomBackgrounds(updatedCustom);
    setBackgrounds([...BACKGROUNDS, ...updatedCustom]);
    setActiveBackground(bg);
    Storage.saveBackground(bg);
  };

  // Screen understanding analysis
  const handleAnalyzeScreen = async (
    imageBase64: string,
    prompt: string
  ): Promise<{ analysis: string; emotion: ExpressionType }> => {
    try {
      const res = await fetch('/api/screen-understand', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: imageBase64,
          prompt,
          userApiKey: userApiKey || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        return {
          analysis: data.error || 'Failed to inspect screen.',
          emotion: 'concerned',
        };
      }
      return {
        analysis: data.analysis || 'Screen analyzed successfully.',
        emotion: (data.emotion as ExpressionType) || 'curious',
      };
    } catch {
      return {
        analysis: 'Failed to connect to screen analysis service.',
        emotion: 'concerned',
      };
    }
  };

  const handleUpdateProfile = (updated: UserProfile) => {
    setCurrentUser(updated);
    Storage.saveUserProfile(updated);
    setShowEditProfileModal(false);
  };

  const handleHeartTap = () => {
    if (settings.soundEffects) playChime('heart');
    setExpression('happy');

    const compliments =
      character === 'jarvis'
        ? [
            `System optimal. Glad to assist, ${currentUser.displayName}.`,
            'Core processing running at peak efficiency.',
            'Always prepared. What is our next objective?',
          ]
        : [
            `Yay! I love chatting with you, ${currentUser.displayName}! 💖`,
            'Hehe, thank you for being wonderful! 🌸',
            'Always here for you! You make every day brighter! ✨',
          ];

    const picked = compliments[Math.floor(Math.random() * compliments.length)];
    const voiceStyle = getActiveVoiceStyle();
    CompanionTTS.speak(picked, voiceStyle, {
      volume: settings.voiceVolume,
      speed: settings.voiceSpeed,
      pitch: settings.voicePitch,
      languageMode: 'english',
    });
  };

  const renderCurrentScreen = () => {
    switch (currentScreen) {
      case 'splash':
        return (
          <SplashScreen
            currentCompanion={character}
            onSelectCompanion={handleSwitchCompanion}
            onEnterApp={() => setCurrentScreen('home')}
            hasGeminiKey={hasServerKey || !!userApiKey}
          />
        );

      case 'onboarding':
        return (
          <NewOnboardingScreen
            initialCompanion={character}
            onSelectCompanion={handleSwitchCompanion}
            onFinishOnboarding={(profile, token) => {
              setCurrentUser(profile);
              setSessionToken(token);
              Storage.saveUserProfile(profile);
              Storage.saveAuthSession({ token, user: profile });
              setCurrentScreen('home');
            }}
          />
        );

      case 'api_setup':
        return (
          <ApiKeySetupScreen
            currentCompanion={character}
            savedApiKey={userApiKey}
            hasServerKey={hasServerKey}
            onSaveKeyAndProceed={(key) => {
              setUserApiKey(key);
              Storage.saveApiKey(key);
              setCurrentScreen('home');
            }}
            onSkipWithServerDefault={() => setCurrentScreen('home')}
            onBack={() => setCurrentScreen('home')}
          />
        );

      case 'home':
        return (
          <HomeScreen
            character={character}
            onSwitchCompanion={handleSwitchCompanion}
            expression={expression}
            isSpeaking={isSpeaking}
            isListening={isListening}
            isThinking={isThinking}
            userName={currentUser?.displayName || settings.userName || 'Gamingfire'}
            messages={messages}
            avatarSize={settings.avatarSize}
            onChangeAvatarSize={(s) => handleUpdateSettings({ avatarSize: s })}
            onSendMessage={(text, img) => handleSendMessage(text, img)}
            onOpenChat={() => setCurrentScreen('chat')}
            onOpenVoice={() => setCurrentScreen('voice')}
            onOpenVoiceSettings={() => setCurrentScreen('voice')}
            onOpenDrawer={() => setIsMenuOpen(true)}
            hasGeminiKey={hasServerKey || !!userApiKey}
            onToggleVoice={handleToggleVoice}
            isAutoVoiceActive={isAutoVoiceActive}
            onHoldToTalkStart={handleHoldToTalkStart}
            onHoldToTalkEnd={handleHoldToTalkEnd}
            lastVoiceTranscript={lastVoiceTranscript}
            onCancelVoice={handleCancelVoice}
            recognitionState={recognitionState}
            micErrorMessage={micErrorMessage}
            onClearMicError={() => setMicErrorMessage(null)}
            onOpenStudio={() => setShowStudioModal(true)}
            onOpenMemory={() => setCurrentScreen('memory')}
            onOpenBackgrounds={() => setCurrentScreen('backgrounds')}
            onOpenSettings={() => setCurrentScreen('settings')}
            onOpenProfile={() => setShowEditProfileModal(true)}
            onOpenTools={() => setCurrentScreen('phone_control')}
            onOpenPersonality={() => setShowStudioModal(true)}
            onOpenAutoFeatures={() => setShowAutoFeaturesModal(true)}
            autoFeatures={autoFeatures}
            coreCustomization={coreCustomization}
            onSpeakMessage={handleSpeakMessage}
          />
        );

      case 'studio':
        return (
          <CoreCustomizationStudio
            isOpen={true}
            onClose={() => setCurrentScreen('home')}
            activeCompanion={character}
            onSwitchCompanion={handleSwitchCompanion}
            customization={coreCustomization}
            onSaveCustomization={(c) => {
              setCoreCustomization(c);
              handleUpdateSettings({ coreCustomization: c });
            }}
          />
        );

      case 'chat':
        return (
          <ChatScreen
            messages={messages}
            isThinking={isThinking}
            isStreaming={isStreaming}
            isListening={isListening}
            isSpeaking={isSpeaking}
            onStopSpeaking={handleStopSpeaking}
            onSendMessage={handleSendMessage}
            onToggleVoice={handleToggleVoice}
            onStartVoiceCall={() => setCurrentScreen('voice')}
            onClearChat={() => {
              const fresh = Storage.loadMessages(character, currentUser?.displayName);
              setMessages(fresh);
              Storage.saveMessages(character, fresh);
            }}
            onSpeakMessage={handleSpeakMessage}
            onRetryLastMessage={() => {
              const userLast = [...messages].reverse().find((m) => m.role === 'user');
              if (userLast) handleSendMessage(userLast.text);
            }}
            character={character}
            recognitionState={recognitionState}
            micErrorMessage={micErrorMessage}
            onClearMicError={() => setMicErrorMessage(null)}
            userName={currentUser?.displayName || settings.userName}
          />
        );

      case 'voice':
        return (
          <VoiceScreen
            character={character}
            onSwitchCompanion={handleSwitchCompanion}
            voices={VOICE_STYLES.filter((v) => v.character === character)}
            selectedVoice={getActiveVoiceStyle()}
            onSelectVoice={(voice) => {
              if (character === 'jarvis') {
                handleUpdateSettings({ jarvisVoice: voice.id as any });
              } else {
                handleUpdateSettings({ alyaVoiceId: voice.id, selectedVoiceId: voice.id });
              }
            }}
            isListening={isListening}
            isSpeaking={isSpeaking}
            isThinking={isThinking}
            isAutoVoiceActive={isAutoVoiceActive}
            onHoldToTalkStart={handleHoldToTalkStart}
            onHoldToTalkEnd={handleHoldToTalkEnd}
            onToggleListening={handleToggleVoice}
            onEndCall={() => setCurrentScreen('home')}
            onStopSpeaking={handleStopSpeaking}
            expression={expression}
            speechVolume={settings.voiceVolume}
            speechSpeed={settings.voiceSpeed}
            speechPitch={settings.voicePitch}
            onChangeVolume={(v) => handleUpdateSettings({ voiceVolume: v })}
            onChangeSpeed={(v) => handleUpdateSettings({ voiceSpeed: v })}
            onChangePitch={(v) => handleUpdateSettings({ voicePitch: v })}
            lastTranscript={lastVoiceTranscript}
            alyaVoiceReply={alyaVoiceReply}
            onPreviewVoice={(voice) => {
              const sample =
                voice.character === 'jarvis'
                  ? 'All systems nominal. How may I assist you today?'
                  : 'Hello! I am excited to talk with you! Let us have fun!';
              CompanionTTS.speak(sample, voice, {
                volume: settings.voiceVolume,
                speed: settings.voiceSpeed,
                pitch: settings.voicePitch,
                languageMode: 'english',
              });
            }}
            recognitionState={recognitionState}
            micErrorMessage={micErrorMessage}
            onClearMicError={() => setMicErrorMessage(null)}
            onSendMessage={handleSendMessage}
            onOpenChat={() => setCurrentScreen('chat')}
            onOpenStudio={() => setShowStudioModal(true)}
            onOpenAutoFeatures={() => setShowAutoFeaturesModal(true)}
            autoFeatures={autoFeatures}
            userName={currentUser?.displayName || settings.userName || 'Gamingfire'}
            coreCustomization={coreCustomization}
          />
        );

      case 'memory':
        return (
          <MemoryScreen
            memories={memories}
            onAddMemory={handleAddMemory}
            onEditMemory={handleEditMemory}
            onDeleteMemory={handleDeleteMemory}
            onTogglePin={handleTogglePinMemory}
          />
        );

      case 'backgrounds':
        return (
          <BackgroundsScreen
            backgrounds={backgrounds}
            activeBackground={activeBackground}
            onApplyBackground={handleApplyBackground}
            onAddCustomBackground={handleAddCustomBackground}
          />
        );

      case 'phone_control':
        return (
          <PhoneControlScreen
            onOpenScreenTools={() => setCurrentScreen('screen_tools')}
            onSendAlyaMessage={(msg) => handleSendMessage(msg)}
            userName={currentUser?.displayName || settings.userName}
          />
        );

      case 'screen_tools':
        return <ScreenToolsScreen onAnalyzeScreen={handleAnalyzeScreen} />;

      case 'settings':
        return (
          <SettingsScreen
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            onResetSettings={handleResetSettings}
            hasGeminiKey={hasServerKey}
            userApiKey={userApiKey}
            onSaveApiKey={(key) => {
              setUserApiKey(key);
              Storage.saveApiKey(key);
            }}
            onRemoveApiKey={() => {
              setUserApiKey('');
              Storage.removeApiKey();
            }}
            currentUser={currentUser}
            sessionToken={sessionToken}
            onUpdateProfile={(p) => setCurrentUser(p)}
            onLogoutUser={() => {
              Storage.clearAuthSession();
              setSessionToken(null);
            }}
            onOpenGuide={() => setCurrentScreen('help')}
            onOpenAutoFeatures={() => setShowAutoFeaturesModal(true)}
            onRequestLocationPermission={() => setShowLocationModal(true)}
          />
        );

      case 'help':
        return (
          <OnboardingGuideScreen
            currentCompanion={character}
            userName={currentUser?.displayName || settings.userName}
            onCompleteOnboarding={() => setCurrentScreen('home')}
            onBack={() => setCurrentScreen('home')}
            isStandalone={true}
          />
        );

      case 'admin':
        if (adminToken) {
          return (
            <AdminControlPanel
              token={adminToken}
              adminEmail={adminEmail}
              onLogout={() => {
                setAdminToken(null);
                localStorage.removeItem('alya_admin_token_v1');
                setCurrentScreen('home');
              }}
              onBackToApp={() => setCurrentScreen('home')}
            />
          );
        }
        return (
          <AdminLoginScreen
            onLoginSuccess={(token, email) => {
              setAdminToken(token);
              setAdminEmail(email);
              localStorage.setItem('alya_admin_token_v1', token);
              localStorage.setItem('alya_admin_email_v1', email);
            }}
            onBackToApp={() => setCurrentScreen('home')}
            hasActiveSession={!!adminToken}
          />
        );

      case 'about':
        return (
          <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center select-none">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-pink-500/20 via-purple-500/30 to-amber-500/20 border border-white/20 flex items-center justify-center mb-4 shadow-xl backdrop-blur-md">
              <span className="text-3xl font-bold bg-gradient-to-r from-pink-400 via-rose-300 to-amber-300 bg-clip-text text-transparent">
                {character === 'jarvis' ? 'J' : 'A'}
              </span>
            </div>
            <h2 className="text-2xl font-bold text-white mb-1">
              {character === 'jarvis' ? 'Jarvis AI Core v3.8' : 'Alya AI Companion v3.8'}
            </h2>
            <p className="text-sm text-slate-400 max-w-sm mb-6">
              Interactive anime & sci-fi companion with live neural voice synthesis, dynamic time awareness, Hinglish & English adaptation, and hands-free continuous dialogue.
            </p>
            <div className="glass-panel p-4 rounded-xl max-w-sm w-full space-y-2 text-left text-xs text-slate-300 mb-6">
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-slate-400">System Timezone</span>
                <span className="font-semibold text-white">{TimeEngine.getTimezone()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-slate-400">AI Intelligence</span>
                <span className="font-semibold text-white">Gemini 3.8 Flash</span>
              </div>
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-slate-400">Neural TTS</span>
                <span className="font-semibold text-white">Gemini 3.8 Flash Lite TTS</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Hands-Free Flow</span>
                <span className="font-semibold text-emerald-400">Auto Listen & Auto Reply</span>
              </div>
            </div>
            <button
              onClick={() => setCurrentScreen('home')}
              className="px-6 py-2.5 rounded-full bg-gradient-to-r from-pink-500 to-purple-600 text-white font-medium text-sm shadow-lg hover:brightness-110 transition-all active:scale-95"
            >
              Back to Home
            </button>
          </div>
        );

      case 'slides':
        return (
          <SlidesScreen
            character={character}
            userName={currentUser?.displayName || settings.userName}
            userApiKey={userApiKey}
            onBackToHome={() => setCurrentScreen('home')}
          />
        );

      case 'work':
        return (
          <WorkScreen
            character={character}
            onSwitchCompanion={handleSwitchCompanion}
            expression={expression}
            isSpeaking={isSpeaking}
            isListening={isListening}
            isThinking={isThinking}
            userName={currentUser?.displayName || settings.userName || 'Gamingfire'}
            userApiKey={userApiKey}
            hasGeminiKey={hasServerKey || !!userApiKey}
            isAutoVoiceActive={isAutoVoiceActive}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
            onToggleVoice={handleToggleVoice}
            onSendMessage={(text, img) => handleSendMessage(text, img)}
            onReturnToNormalMode={() => setCurrentScreen('home')}
            onOpenDrawer={() => setIsMenuOpen(true)}
            lastVoiceTranscript={lastVoiceTranscript}
            onStopSpeaking={handleStopSpeaking}
            autoFeatures={autoFeatures}
            onUpdateAutoFeatures={handleUpdateAutoFeatures}
            messages={messages}
            micErrorMessage={micErrorMessage}
          />
        );

      default:
        return null;
    }
  };

  const showTopBar =
    currentScreen !== 'splash' &&
    currentScreen !== 'onboarding' &&
    currentScreen !== 'admin' &&
    currentScreen !== 'work';

  return (
    <div className="relative w-full h-screen overflow-hidden bg-[#030107] text-white flex items-center justify-center select-none">
      <div
        className={`relative w-full h-full flex flex-col overflow-hidden transition-all duration-300 ${
          isPhoneFrame
            ? 'max-w-[430px] max-h-[92vh] rounded-[44px] border-[10px] border-[#181822] shadow-[0_25px_60px_rgba(0,0,0,0.85)] ring-1 ring-white/10 my-auto'
            : 'max-w-none h-full'
        }`}
      >
        <AnimatedCompanionBackground character={character} />

        {settings.dynamicIslandEnabled && currentScreen !== 'splash' && currentScreen !== 'onboarding' && (
          <DynamicIsland
            visible={isSpeaking || isListening || isThinking}
            isSpeaking={isSpeaking}
            isListening={isListening}
            statusText={
              isSpeaking
                ? `${character === 'jarvis' ? 'Jarvis' : 'Alya'} Speaking...`
                : isListening
                ? 'Listening to you...'
                : 'Thinking...'
            }
            onTap={() => {
              if (currentScreen !== 'voice') setCurrentScreen('voice');
            }}
          />
        )}

        <FloatingMiniAlya
          visible={floatingMiniVisible}
          isSpeaking={isSpeaking}
          isListening={isListening}
          onOpenApp={() => {
            setFloatingMiniVisible(false);
            setCurrentScreen('home');
          }}
          onClose={() => setFloatingMiniVisible(false)}
        />

        {showTopBar && (
          <TopBar
            currentScreen={currentScreen}
            onNavigate={(screen) => setCurrentScreen(screen)}
            onOpenMenu={() => setIsMenuOpen(true)}
            onHeartTap={handleHeartTap}
            isPhoneFrame={isPhoneFrame}
            onTogglePhoneFrame={() => setIsPhoneFrame((prev) => !prev)}
            companionStatus={isSpeaking ? 'Speaking' : isListening ? 'Listening' : 'Online'}
            character={character}
          />
        )}

        <main className="relative flex-1 w-full h-full overflow-hidden flex flex-col z-10">
          {renderCurrentScreen()}
        </main>

        <MenuDrawer
          isOpen={isMenuOpen}
          onClose={() => setIsMenuOpen(false)}
          currentScreen={currentScreen}
          onSelectScreen={(screen) => {
            setCurrentScreen(screen);
            setIsMenuOpen(false);
          }}
          userName={currentUser?.displayName || settings.userName || 'Gamingfire'}
          character={character}
          currentUser={currentUser}
          onOpenAutoFeatures={() => setShowAutoFeaturesModal(true)}
        />

        {showEditProfileModal && (
          <EditProfileModal
            isOpen={showEditProfileModal}
            currentUser={currentUser}
            sessionToken={sessionToken}
            companion={character}
            onClose={() => setShowEditProfileModal(false)}
            onProfileUpdated={handleUpdateProfile}
          />
        )}

        {showStudioModal && (
          <CoreCustomizationStudio
            isOpen={showStudioModal}
            onClose={() => setShowStudioModal(false)}
            activeCompanion={character}
            onSwitchCompanion={handleSwitchCompanion}
            customization={coreCustomization}
            onSaveCustomization={(c) => {
              setCoreCustomization(c);
              handleUpdateSettings({ coreCustomization: c });
            }}
          />
        )}

        {showAutoFeaturesModal && (
          <AutoFeaturesModal
            isOpen={showAutoFeaturesModal}
            onClose={() => setShowAutoFeaturesModal(false)}
            character={character}
            autoFeatures={autoFeatures}
            onUpdateAutoFeatures={handleUpdateAutoFeatures}
          />
        )}

        {showLocationModal && (
          <LocationPermissionModal
            isOpen={showLocationModal}
            onClose={() => setShowLocationModal(false)}
            onAllow={() => {
              handleUpdateSettings({
                locationPermissionGranted: true,
                locationPermissionPrompted: true,
              });
            }}
            onDeny={() => {
              handleUpdateSettings({
                locationPermissionGranted: false,
                locationPermissionPrompted: true,
              });
            }}
          />
        )}
      </div>
    </div>
  );
}
